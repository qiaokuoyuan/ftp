package com.macro.mall.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.macro.mall.enu.RateType;

@Entity
public class Rate {
	@Id
	private String id;

//	打分者的id
	private String rateUser;

//	被打分项的id
	private String targetId;

//打分分数
	private Double rateScore;

	public Double getRateScore() {
		return rateScore;
	}

	public void setRateScore(Double rateScore) {
		this.rateScore = rateScore;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRateUser() {
		return rateUser;
	}

	public void setRateUser(String rateUser) {
		this.rateUser = rateUser;
	}

	public String getTargetId() {
		return targetId;
	}

	public void setTargetId(String targetId) {
		this.targetId = targetId;
	}

}
