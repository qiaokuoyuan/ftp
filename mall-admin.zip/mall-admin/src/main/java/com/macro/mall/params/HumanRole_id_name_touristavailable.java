package com.macro.mall.params;

public class HumanRole_id_name_touristavailable {

	private String id;
	private String name;

	private boolean touristAvailable;

	public boolean isTouristAvailable() {
		return touristAvailable;
	}

	public HumanRole_id_name_touristavailable setTouristAvailable(boolean touristAvailable) {
		this.touristAvailable = touristAvailable;
		return this;
	}

	public String getId() {
		return id;
	}

	public HumanRole_id_name_touristavailable setId(String id) {
		this.id = id;
		return this;
	}

	public String getName() {
		return name;
	}

	public HumanRole_id_name_touristavailable setName(String name) {
		this.name = name;
		return this;
	}

}
