package com.macro.mall.controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.CompetionSponser;
import com.macro.mall.entity.Competition;
import com.macro.mall.jpa.CompetionSponserRepo;
import com.macro.mall.jpa.CompetitionRepo;

@Controller
@RequestMapping("/competition")
public class CompetionController {

	@Autowired
	private CompetionSponserRepo competionSponserRepo;

	@Autowired
	private CompetitionRepo competitionRepo;

	public CompetionSponserRepo getCompetionSponserRepo() {
		return competionSponserRepo;
	}

	public void setCompetionSponserRepo(CompetionSponserRepo competionSponserRepo) {
		this.competionSponserRepo = competionSponserRepo;
	}

	public CompetitionRepo getCompetitionRepo() {
		return competitionRepo;
	}

	public void setCompetitionRepo(CompetitionRepo competitionRepo) {
		this.competitionRepo = competitionRepo;
	}

	/**
	 * 添加比賽舉辦方
	 * 
	 * @param competionSponser
	 * @return
	 */
	@RequestMapping("/addCompetitionSponser")
	@ResponseBody
	public Object addCompetitionSponser(CompetionSponser competionSponser) {
		try {
			competionSponser.setId(UUID.randomUUID().toString());
			competionSponserRepo.save(competionSponser);
			return new CommonResult().success(competionSponser.getId());
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 编辑比赛举办方
	 * 
	 * @param competionSponser
	 * @return
	 */
	@RequestMapping("/editCompetitionSponser")
	@ResponseBody
	public Object editCompetitionSponser(CompetionSponser competionSponser) {
		try {
			competionSponserRepo.save(competionSponser);
			return new CommonResult().success("编辑成功");
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 删除比赛举办方
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/delCompetitionSponser")
	@ResponseBody
	public Object delCompetitionSponser(String id) {
		try {
			competionSponserRepo.delete(id);
			return new CommonResult().success("删除成功");
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 获取所有比赛举办方
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/getCompetitionSponsers")
	@ResponseBody
	public Object getCompetitionSponsers() {
		try {
			return new CommonResult().success(competionSponserRepo.findAll());
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 获取所有比赛
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/getAllCompetitions")
	@ResponseBody
	public Object getAllCompetitions() {
		try {
			return new CommonResult().success(competitionRepo.findAll());
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 添加比賽舉辦方
	 * 
	 * @param competionSponser
	 * @return
	 */
	@RequestMapping("/addCompetition")
	@ResponseBody
	public Object addCompetition(Competition competition,String sponserId) {
		try {
			competition.setId(UUID.randomUUID().toString());
			competition.setCompetionSponser(competionSponserRepo.findOne(sponserId));
			competitionRepo.save(competition);
			return new CommonResult().success(competition.getId());
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 编辑比赛举办方
	 * 
	 * @param competionSponser
	 * @return
	 */
	@RequestMapping("/editCompetition")
	@ResponseBody
	public Object editCompetition(Competition competition) {
		try {
			competitionRepo.save(competition);
			return new CommonResult().success("编辑成功");
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 删除比赛
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/delCompetition")
	@ResponseBody
	public Object delCompetition(String id) {
		try {
			competionSponserRepo.delete(id);
			return new CommonResult().success("删除成功");
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

}
