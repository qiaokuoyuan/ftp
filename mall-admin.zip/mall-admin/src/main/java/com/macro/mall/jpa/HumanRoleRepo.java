package com.macro.mall.jpa;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.macro.mall.entity.HumanRole;
import com.macro.mall.params.HumanPermissionString;

public interface HumanRoleRepo extends JpaRepository<HumanRole, String> {


}
