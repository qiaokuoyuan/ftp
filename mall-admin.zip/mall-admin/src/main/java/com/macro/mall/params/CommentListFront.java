package com.macro.mall.params;

import java.util.Date;

import org.springframework.stereotype.Component;

/**
 * 前端在获取评论列表时返回的评论集合
 * 
 * @author Naga
 *
 */
@Component
public class CommentListFront {
	private String id;
	private String commentContent;
	private Date commentTime;
	private String creatorId;
	private String creatorName;
	private String creatorLogo;
	
	
	public CommentListFront() {
		// TODO Auto-generated constructor stub
	}
	
	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCommentContent() {
		return commentContent;
	}

	public void setCommentContent(String commentContent) {
		this.commentContent = commentContent;
	}

	public Date getCommentTime() {
		return commentTime;
	}

	public void setCommentTime(Date commentTime) {
		this.commentTime = commentTime;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getCreatorLogo() {
		return creatorLogo;
	}

	public void setCreatorLogo(String creatorLogo) {
		this.creatorLogo = creatorLogo;
	}

	public CommentListFront(String id, String commentContent, Date commentTime, String creatorId, String creatorName,
			String creatorLogo) {
		super();
		this.id = id;
		this.commentContent = commentContent;
		this.commentTime = commentTime;
		this.creatorId = creatorId;
		this.creatorName = creatorName;
		this.creatorLogo = creatorLogo;
	}

}
