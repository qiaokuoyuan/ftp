package com.macro.mall.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Comment2  extends BaseEntity{


	private String title;
	private String content;




	// 附件的文件code
	private String attachmentFileCode;

	public String getAttachmentFileCode() {
		return attachmentFileCode;
	}

	public void setAttachmentFileCode(String attachmentFileCode) {
		this.attachmentFileCode = attachmentFileCode;
	}

	// 评论对象的id
	private String targetId;



	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}



	public String getTargetId() {
		return targetId;
	}

	public void setTargetId(String targetId) {
		this.targetId = targetId;
	}

}
