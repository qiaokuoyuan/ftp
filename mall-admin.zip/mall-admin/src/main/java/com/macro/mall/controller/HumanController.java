package com.macro.mall.controller;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.Human;
import com.macro.mall.entity.HumanRole;
import com.macro.mall.jpa.HumanRepo;
import com.macro.mall.jpa.HumanRoleRepo;
import com.macro.mall.params.UserWithRoleName;

@RequestMapping("/human")
@Controller
@Component
public class HumanController extends BaseController<Human> {

	@Autowired
	private HumanRepo humanRepo;

	@Autowired
	private HumanRoleRepo humanRoleRepo;

	public HumanRoleRepo getHumanRoleRepo() {
		return humanRoleRepo;
	}

	public void setHumanRoleRepo(HumanRoleRepo humanRoleRepo) {
		this.humanRoleRepo = humanRoleRepo;
	}

	public HumanRepo getHumanRepo() {
		return humanRepo;
	}

	public void setHumanRepo(HumanRepo humanRepo) {
		this.humanRepo = humanRepo;
	}

	@Autowired
	public void setRepo() {
		this.setRepo(this.humanRepo);
	}

	/**
	 * 获取后台审核的用户列表
	 * 
	 * @param h
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	@RequestMapping("/backList")
	@ResponseBody
	public Object getDetail(Human h, @RequestParam(defaultValue = "1") Integer pageIndex,
			@RequestParam(defaultValue = "10") Integer pageSize) {
		pageIndex--;
		Page<Human> findAll = humanRepo.findAll(Example.of(h), new PageRequest(pageIndex, pageSize));
		List<UserWithRoleName> details = findAll.getContent().stream().map(e -> UserWithRoleName.fromHuman(e))
				.collect(Collectors.toList());
		return new CommonResult().success(details).addAdditionalAttribute("total", findAll.getTotalElements());
	}

	/**
	 * 从后台直接删除一个用户
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/delBack")
	@ResponseBody
	@Transactional
	public Object delBack(String id) throws Exception{

		Human human = humanRepo.findOne(id);

		// 取消 角色关联关系
		List<HumanRole> roles = human.getHumanRoles();
		roles.forEach(r -> r.getHumans().removeIf(h -> {
			return h.getId().equals(id);
		}));

		humanRoleRepo.save(roles);
		super.del(id);
		return new CommonResult().success("");

	}

	/**
	 * 从后台直接添加用户
	 * 
	 * @param h
	 * @param roleIds
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping("/addHumanFromBack")
	@ResponseBody
	@Transactional
	public Object addHumanFromBack(HttpServletRequest request, HttpServletResponse response, Human h, String roleIds) throws Exception {

		if (!StringUtils.isEmpty(roleIds)) {
//				如果传入了 角色，将角色传入
			List<HumanRole> roles = Arrays.asList(roleIds.split(",")).stream().map(e -> {
				HumanRole role = humanRoleRepo.findOne(e);
				return role;
			}).collect(Collectors.toList());
			h.setHumanRoles(roles);
		}

		if (StringUtils.isEmpty(h.getId())) {
			h.setPasswordMD5(getBeanTool().md5(h.getRaw_password()));
			return super.add(request, response, h);
		} else {
			return super.update(h);
		}
//				h.setCreatorHuman(currentUser);
	}
}
