package com.macro.mall.controller;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.Human;
import com.macro.mall.entity.Rate;
import com.macro.mall.enu.RateType;
import com.macro.mall.jpa.RateRepo;
import com.macro.mall.util.BeanTool;

/**
 * 各种打分项控制器
 * 
 * @author Administrator
 *
 */
@Controller
@Component
@RequestMapping("/rate")
public class RateController {

	@Autowired
	private RateRepo rateRepo;

	@Autowired
	private BeanTool beanTool;

	public BeanTool getBeanTool() {
		return beanTool;
	}

	public void setBeanTool(BeanTool beanTool) {
		this.beanTool = beanTool;
	}

	public RateRepo getRateRepo() {
		return rateRepo;
	}

	public void setRateRepo(RateRepo rateRepo) {
		this.rateRepo = rateRepo;
	}

	/**
	 * 当前用户给某个东西打分
	 * 
	 * @param targetId  被打分的东西的id
	 * @param rateScore 分值
	 * @param rateType  被打分的东西类型
	 * @return
	 */
	@RequestMapping("/rateTarget")
	@ResponseBody
	public Object rateTarget(HttpServletRequest request, String targetId, Integer rateScore, RateType rateType) {
		try {
			Rate rate = new Rate();

			Human humanByHeader = beanTool.getHumanByHeader(request);

			rate.setRateUser(humanByHeader.getId());
			rate.setTargetId(targetId);
//			检查是否打过分
			if (rateRepo.exists(Example.of(rate))) {
				return new CommonResult().failed("您已经打过分");
			} else {

				rate.setId(UUID.randomUUID().toString());
				rateRepo.save(rate);
				return new CommonResult().success(rate.getId());
			}
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 获取一个目标的平均分
	 * 
	 * @param targetId
	 * @return
	 */
	@RequestMapping("/getAverageRate")
	@ResponseBody
	public Object getAverageRate(String targetId) {
		try {
			return new CommonResult().success(rateRepo.getAverageRate(targetId));
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}
}
