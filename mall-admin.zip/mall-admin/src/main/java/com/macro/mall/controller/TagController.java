package com.macro.mall.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.macro.mall.entity.Tag;
import com.macro.mall.jpa.TagRepo;

@Controller
@Component
@RequestMapping("/tag")
public class TagController extends BaseController<Tag> {

	@Autowired
	private TagRepo tagRepo;

	public TagRepo getTagRepo() {
		return tagRepo;
	}

	public void setTagRepo(TagRepo tagRepo) {
		this.tagRepo = tagRepo;
	}
	
	@Autowired
	public void setRepo() {
		this.setRepo(this.tagRepo);
	}
	
	
}
