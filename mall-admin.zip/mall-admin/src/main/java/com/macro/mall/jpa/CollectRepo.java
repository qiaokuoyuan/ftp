package com.macro.mall.jpa;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.macro.mall.entity.Collect;

@Component
public interface CollectRepo extends JpaRepository<Collect, String> {

//	查询一个用户是否已经收藏过当前资源
	@Query(value = "select count(1) from collect where user_id=?1 and target_id=?2", nativeQuery = true)
	Boolean isUserCollect(String userid, String targetId);

}
