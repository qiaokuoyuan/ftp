package com.macro.mall.params;

import java.util.List;

public class HumanPermissionString {
	private String frontPermissionString;
	private String backPermissionString;

	public HumanPermissionString() {
	}

	public HumanPermissionString(String frontPermissionString, String backPermissionString) {
		super();
		this.frontPermissionString = frontPermissionString;
		this.backPermissionString = backPermissionString;
	}

	public String getFrontPermissionString() {
		return frontPermissionString;
	}

	public HumanPermissionString setFrontPermissionString(String frontPermissionString) {
		this.frontPermissionString = frontPermissionString;
		return this;
	}

	public String getBackPermissionString() {
		return backPermissionString;
	}

	public HumanPermissionString setBackPermissionString(String backPermissionString) {
		this.backPermissionString = backPermissionString;
		return this;
	}
	
	
	public HumanPermissionString(Object o ) {
		try {
			
//			如果是 list 
			if(o instanceof List){
				
				List _list=(List) o;
				String[] ss= (String[]) _list.get(0);
				
				this.frontPermissionString=ss[0];
				this.backPermissionString=ss[1];

			}
			
			
//			this.frontPermissionString=objs.get(0)
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
