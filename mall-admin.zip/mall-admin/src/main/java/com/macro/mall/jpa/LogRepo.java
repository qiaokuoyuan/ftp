package com.macro.mall.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.macro.mall.entity.Log;

public interface LogRepo extends JpaRepository<Log, Long> {

}
