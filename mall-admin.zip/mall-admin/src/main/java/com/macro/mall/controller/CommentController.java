package com.macro.mall.controller;

import java.util.Date;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.Comment;
import com.macro.mall.entity.Human;
import com.macro.mall.jpa.CommentRepo;
import com.macro.mall.params.CommentListFront;
import com.macro.mall.util.BeanTool;

@Controller
@RequestMapping("/comment")
public class CommentController {

	@Value("${token_name}")
	public String token_name;

	@Autowired
	public BeanTool beanTool;

	@Autowired
	private CommentRepo commentRepo;

	public CommentRepo getCommentRepo() {
		return commentRepo;
	}

	public void setCommentRepo(CommentRepo commentRepo) {
		this.commentRepo = commentRepo;
	}

	/**
	 * 给一个目标添加评论
	 * 
	 * @param comment
	 * @return
	 */
	@RequestMapping("/addComment")
	@ResponseBody
	public Object addComment(HttpServletRequest request, Comment comment) {
		try {

			Human human = beanTool.getHumanByHeader(request, token_name);
			comment.setCreateTime(new Date());
			comment.setCreatorHuman(human);
			comment.setId(UUID.randomUUID().toString());
			commentRepo.save(comment);
			return new CommonResult().success(comment.getId());
		} catch (Exception e) {
			return new CommonResult().failed();
		}
	}

	/**
	 * 获取一个目标的所有评论
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/findCommentsByTarget")
	@ResponseBody
	public Object findCommentsByTarget(String targetId, @RequestParam(defaultValue = "false") Boolean needLogo) {
		try {
			if (needLogo) {
				return new CommonResult().success(commentRepo._find_by_targetId_with_logo(targetId));
			} else {
				return new CommonResult().success(commentRepo.findByTargetId(targetId));
			}

		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 根据targetId获取评论
	 * 
	 * @return
	 */
	@RequestMapping("/getFrontCommentsByTargetId")
	@ResponseBody
	public Object getFrontCommentsByTargetId(String targetId, @RequestParam(defaultValue = "1") Integer pageIndex,
			@RequestParam(defaultValue = "10") Integer pageSize) {
		try {

			Pageable page = new PageRequest(pageIndex, pageSize);
			Object frontCommentsByTargetId = commentRepo.getFrontCommentsByTargetId(targetId);
			return new CommonResult().success(frontCommentsByTargetId);

		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 删除一个评论
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/delComment")
	@ResponseBody
	public Object delComment(String id) {
		try {
			commentRepo.delete(id);
			return new CommonResult().success(null);
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}
}
