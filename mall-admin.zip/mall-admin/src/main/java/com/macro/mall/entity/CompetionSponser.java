package com.macro.mall.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * 比赛举办者实体类，类似kaggle
 * 
 * @author Administrator
 *
 */
@Entity
public class CompetionSponser {

	@Id
	private String id;
	private String name;

	private String logo;

	private String link;
	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	
}
