package com.macro.mall.controller;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.BaseEntity;
import com.macro.mall.entity.Human;
import com.macro.mall.jpa.HumanRepo;
import com.macro.mall.util.BeanTool;

@Controller
@Component
public class BaseController<T extends BaseEntity> {

	@Value(value = "${token_name}")
	public String token_name;
	private JpaRepository repo;

	private HttpServletRequest request;
	private HttpServletResponse response;

	@Autowired
	private BeanTool beanTool;

	@Autowired
	private HumanRepo humanRepo;

	/**
	 * 获取当前登录用户
	 * 
	 * @param t
	 * @return
	 */
	protected Human getCurrentUser(HttpServletRequest request) {
		String userid = (String) request.getServletContext().getAttribute("user-id");

//		检查是否存储有 userid
		if (StringUtils.isEmpty(userid)) {
			return null;
		} else {
			Human human = humanRepo.findOne(userid);
			return human;
		}
	}

	public BeanTool getBeanTool() {
		return beanTool;
	}

	public void setBeanTool(BeanTool beanTool) {
		this.beanTool = beanTool;
	}

	public HumanRepo getHumanRepo() {
		return humanRepo;
	}

	public void setHumanRepo(HumanRepo humanRepo) {
		this.humanRepo = humanRepo;
	}

	public JpaRepository getRepo() {
		return repo;
	}

	public void setRepo(JpaRepository repo) {
		this.repo = repo;
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}

	@RequestMapping("/detail")
	@ResponseBody
	public Object detail(String id) {
		try {
			T t = (T) repo.findOne(id);
			return new CommonResult().success(t);
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	@RequestMapping("/add")
	@ResponseBody
	public Object add(HttpServletRequest request, HttpServletResponse response, T t) {
		try {

			Human human = beanTool.getHumanByHeader(request, token_name);

//			如果未登录
			if (human == null) {
				return new CommonResult().failed("用户未登录");
			}

			t.setId(UUID.randomUUID().toString());
			t.setCreatorHuman(human);
			t.setCreateTime(new Date());

			repo.save(t);
			return new CommonResult().success(t.getId());
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}

	}

	/**
	 * 删除
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/del")
	@ResponseBody
	public Object del(String id) {
		try {
			repo.delete(id);
			return new CommonResult().success("删除成功");
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}

	}

	@RequestMapping("/update")
	@ResponseBody
	public Object update(T t) {
		try {
//			从数据库中取出原始 对象
			T old_t = (T) repo.findOne(t.getId());

//			复制非空属性
			beanTool.unNullCopy(old_t, t);

//			保存对象
			repo.save(old_t);

			return new CommonResult().success("更新成功");
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}

	}

	@RequestMapping("/getOne")
	@ResponseBody
	public Object getOne(String id) {
		try {
			return new CommonResult().success(repo.findOne(id));
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 分页查询
	 * 
	 * @param example
	 * @param pageIndex
	 * @param pageSize
	 * @param sort
	 * @param order
	 * @return
	 */
	@RequestMapping("/get")
	@ResponseBody()
	public Object get(T example, @RequestParam(defaultValue = "1") Integer pageIndex,
			@RequestParam(defaultValue = "10") Integer pageSize, @RequestParam(defaultValue = "") String sort,
			@RequestParam(defaultValue = "desc") String order) {
		try {

			if (pageIndex > 0 && pageSize > 0) {
//			如果需要分页				

				Pageable page = null;

				if (!StringUtils.isEmpty(sort)) {
//				如果指定排序字段

					order = order.toLowerCase();
					if (order.equals("a") || order.equals("asc")) {
//						如果是正序
						page = new PageRequest(pageIndex - 1, pageSize, Sort.Direction.ASC, sort);
					} else {
//						如果是倒序
						page = new PageRequest(pageIndex - 1, pageSize, Sort.Direction.DESC, sort);
					}
				} else {
					page = new PageRequest(pageIndex - 1, pageSize);
				}

//				检查是否给定了example
				if (beanTool.notNullFeatureCount(example) == 0) {
					Page findAll = repo.findAll(page);
					return new CommonResult().success(findAll);

				} else {
					return new CommonResult().success(repo.findAll(Example.of(example), page));
				}
			} else {
//				如果不需要分页
//				检查是否给定了example
				if (beanTool.notNullFeatureCount(example) > 0) {
					return new CommonResult().success(repo.findAll(Example.of(example)));
				} else {

					List findAll = repo.findAll();
					Object removeCreatorPassword = beanTool.removeCreatorPassword(findAll);

					return new CommonResult().success(removeCreatorPassword);
				}
			}

		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}

	}
}
