package com.macro.mall.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.About;
import com.macro.mall.jpa.AboutRepo;

@RequestMapping("/about")
@Controller
public class AboutController extends BaseController<About> {

	@Autowired
	private AboutRepo aboutRepo;

	public AboutRepo getAboutRepo() {
		return aboutRepo;
	}

	public void setAboutRepo(AboutRepo aboutRepo) {
		this.aboutRepo = aboutRepo;
	}

	@Autowired
	public void setRepo() {
		this.setRepo(this.aboutRepo);
	}
	
	
	/**
	 * 获取激活的about
	 * @return
	 */
	@RequestMapping("/getActive")
	@ResponseBody
	public Object getActive() {
		try {
			return new CommonResult().success(aboutRepo.findByIsActive(true));
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}
	
	@RequestMapping("/active")
	@ResponseBody
	@Transactional
	public Object active(String id) {
		try {
			aboutRepo.disactiveAll();
			aboutRepo.activeOne(id);
			return new CommonResult().success(null);
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}
	
	
	
	
}
