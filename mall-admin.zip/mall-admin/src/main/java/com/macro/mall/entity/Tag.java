package com.macro.mall.entity;

import javax.persistence.Entity;

@Entity
public class Tag extends BaseEntity {

	private String tagName;
	
	private String targetId;
	
	
	public String getTargetId() {
		return targetId;
	}

	public void setTargetId(String targetId) {
		this.targetId = targetId;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

}
