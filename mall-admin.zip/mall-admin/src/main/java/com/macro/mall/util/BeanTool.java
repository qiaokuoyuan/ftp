package com.macro.mall.util;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;
import org.springframework.util.DigestUtils;
import org.springframework.util.StringUtils;

import com.macro.mall.cache.CachePool;
import com.macro.mall.cache.SimpleCache;
import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.BaseEntity;
import com.macro.mall.entity.Human;
import com.macro.mall.entity.HumanRole;
import com.macro.mall.entity.Permission;
import com.macro.mall.entity.WebConfig;
import com.macro.mall.jpa.HumanRepo;
import com.macro.mall.jpa.LogRepo;
import com.macro.mall.jpa.WebConfigRepo;

@Component
public class BeanTool {

	@Autowired
	private LogRepo logRepo;



	@Value("${token_name}")
	public String token_name;

//	Token 向 用户映射关系缓存
	@Autowired
	private CachePool<Human, String> humanTokenCache;
	@Autowired
	private EncryptUtil encoder;
	@Autowired
	private HumanRepo humanRepo;

	@Autowired
	private WebConfigRepo webConfigRepo;

	@Autowired
	private JavaMailSender javaMailSender;

	@Value("${spring.mail.username}")
	public String emailSender;

	public WebConfigRepo getWebConfigRepo() {
		return webConfigRepo;
	}

	public void setWebConfigRepo(WebConfigRepo webConfigRepo) {
		this.webConfigRepo = webConfigRepo;
	}

	public CachePool<Human, String> getHumanTokenCache() {
		return humanTokenCache;
	}

	public void setHumanTokenCache(CachePool<Human, String> humanTokenCache) {
		this.humanTokenCache = humanTokenCache;
	}

	public JavaMailSender getJavaMailSender() {
		return javaMailSender;
	}

	public void setJavaMailSender(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	public EncryptUtil getEncoder() {
		return encoder;
	}

	public void setEncoder(EncryptUtil encoder) {
		this.encoder = encoder;
	}

	public HumanRepo getHumanRepo() {
		return humanRepo;
	}

	public void setHumanRepo(HumanRepo humanRepo) {
		this.humanRepo = humanRepo;
	}

	public String getEmailSender() {
		return emailSender;
	}

	public void setEmailSender(String emailSender) {
		this.emailSender = emailSender;
	}

	public StringEncryptor getStringEncryptor() {
		return stringEncryptor;
	}

	public void setStringEncryptor(StringEncryptor stringEncryptor) {
		this.stringEncryptor = stringEncryptor;
	}

	public LogRepo getLogRepo() {
		return logRepo;
	}

	public void setLogRepo(LogRepo logRepo) {
		this.logRepo = logRepo;
	}

	public StringEncryptor stringEncryptor = new PooledPBEStringEncryptor();

	/**
	 * 删除 创建者的密码信息
	 * 
	 * @param ts
	 */
	public <T extends BaseEntity> Object removeCreatorPassword(Object datas) {

//		如果是list集合
		if (datas instanceof List) {
			List ts = (List) datas;
			return ts.stream().map(e -> removeCreatorPassword(e)).collect(Collectors.toList());
		}

//		如果是分页		
		if (datas instanceof Page) {
			Page ts = (Page) datas;
			ts.getContent().forEach(e -> removeCreatorPassword(e));
			return ts;
		}

//		如果是commonresult 类型， 将其中的data转化	
		if (datas instanceof CommonResult) {
			CommonResult c = (CommonResult) datas;
			c.setData(removeCreatorPassword(c.getData()));
			return c;
		}

//		如果是 单个 entity		
		if (datas instanceof BaseEntity) {
			T t = (T) datas;

			if (t.getCreatorHuman() != null) {
				t.getCreatorHuman().setRaw_password("");
				t.getCreatorHuman().setPasswordMD5("");
			}
			return t;
		} else {
			return datas;
		}

	}

	/**
	 * 返送邮件
	 * 
	 * @param to      发送到哪个邮箱
	 * @param content 发送内容
	 * @throws Exception
	 */
	public void sendEmail(String to, String content) throws Exception {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(to);
		message.setFrom(emailSender);
		message.setSubject("欢迎使用 数据商城，你验证码显示在下方，如果不是您发送的，请忽略");
		message.setText(content);

		javaMailSender.send(message);

	}

//		MD5 加密
	public String md5(String content) throws Exception {
		return DigestUtils.md5DigestAsHex(content.getBytes("utf-8"));
	}

	/**
	 * 判断一个对象不是null的属性个数
	 * 
	 * @param o
	 * @return
	 */
	public Integer notNullFeatureCount(Object o) {

		try {
			Class<? extends Object> OClass = o.getClass();
			Integer count = 0;
			for (Field field : OClass.getDeclaredFields()) {

				if (field.get(o) != null) {
					++count;
				}
			}
			return count;
		} catch (Exception e) {
			return 0;
		}

	}

	/**
	 * 拷贝一个对象，只拷贝非空属性,如果出现异常，将原始对象返回
	 * 
	 * @param s
	 * @return
	 */
	public <S> void unNullCopy(S s_to, S s_from) {
		try {
			String[] ignoreProperties = getNullAttributeNames(s_from);
			BeanUtils.copyProperties(s_from, s_to, ignoreProperties);

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

//	获取一个对象的所有空字段名称
	public String[] getNullAttributeNames(Object s) {
		try {
//			Field[] declaredFields = s.getClass().getFields();
//			List<String> nulllAttrNames = new ArrayList<>();
//			for (Field field : declaredFields) {
//				field.setAccessible(true);
//				Object object =field.get(s);
//				if (Objects.isNull(object)) {
//					nulllAttrNames.add(field.getName());
//				}
//			}
//			
//			String[] names=new String[nulllAttrNames.size()];
//			
//			for (int i = 0; i < names.length; i++) {
//				names[i]=nulllAttrNames.get(i).toString();
//			}
//			return  names ;

			final BeanWrapper src = new BeanWrapperImpl(s);
			java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();

			Set<String> emptyNames = new HashSet<String>();
			for (java.beans.PropertyDescriptor pd : pds) {
				Object srcValue = src.getPropertyValue(pd.getName());
				if (srcValue == null)
					emptyNames.add(pd.getName());
			}
			String[] result = new String[emptyNames.size()];
			return emptyNames.toArray(result);

		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 根据请求 中的cookie 获取当期用户信息
	 * 
	 * @param request
	 * @return
	 */
	public Human getHumanByCookie(HttpServletRequest request, String cookieName) {
		List<Cookie> tokenCookies = Arrays.asList(request.getCookies()).stream().filter(c -> {
			return c.getName().equals(cookieName);
		}).collect(Collectors.toList());
		if (tokenCookies.size() == 0) {
			return null;
		} else {
			return getHumanByCiphter(tokenCookies.get(0).getValue());
		}
	}

	/**
	 * 根据请求头 中的信息 获取当期用户信息
	 * 
	 * @param request
	 * @return
	 */
	public Human getHumanByHeader(HttpServletRequest request, String headerName) {
		String token = request.getHeader(headerName);
		if (StringUtils.isEmpty(token)) {
			return null;
		} else {
			return getHumanByCiphter(token);
		}
	}

	/**
	 * 根据请求头 中的信息 获取当期用户信息
	 * 
	 * @param request
	 * @return
	 */
	public Human getHumanByHeader(HttpServletRequest request) {

		return this.getHumanByHeader(request, token_name);
	}

	/**
	 * 根据 密文 获取当前登录的用户
	 * 
	 * @param request
	 * @return
	 */
	public Human getHumanByCiphter(String cipher) {

		try {

			String token = new String(Base64.getDecoder().decode((cipher.getBytes())));

//			尝试从 cache中找
			if (humanTokenCache.get(token) != null) {
				System.out.println("找到缓存用户");
				return humanTokenCache.get(token);
			}

//			将解密后的token分为2部分
			String[] token_spilt = token.split(",");

//			检查有效性
			if (token_spilt.length == 2) {

//				读取出 用户名 和 加密后的用户名
				String username = token_spilt[0];
				String enc_username = token_spilt[1];

//				检查是否匹配
				if (encoder.match(username, enc_username)) {
//					如果token 有效，查询用户信息
					Human current_user = humanRepo.findByUsername(username).get(0);

//					将查询出的用户放在缓存中
					humanTokenCache.cache(token, current_user);
					return current_user;

				}

				else {
					return null;
				}
			} else {
				return null;
			}
		} catch (Exception e) {
			return null;
		}
	}
}
