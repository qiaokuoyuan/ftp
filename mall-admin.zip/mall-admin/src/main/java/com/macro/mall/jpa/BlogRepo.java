package com.macro.mall.jpa;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.macro.mall.entity.Blog;
import com.macro.mall.params.BlogListFront;

public interface BlogRepo extends JpaRepository<Blog, String> {

	@Query(value = "SELECT b FROM Blog b   WHERE b.blogType.id=?1")
	Page<Blog> selectByBlogTypeId(String blogTypeId, Pageable pageable);

	@Query(value = "select new com.macro.mall.params.BlogListFront(\r\n" + "	b.id,\r\n"
			+ "	b.creatorHuman.logo,\r\n" + "	b.creatorHuman.nickname,\r\n" + "	b.title,\r\n"
			+ "	b.createTime\r\n, b.creatorHuman.id" + "	\r\n" + "	)\r\n"
			+ "from com.macro.mall.entity.Blog b", countQuery = "select count(1) from Blog ")
	Page<BlogListFront> search(Pageable pageable);

	@Query(value = "select new com.macro.mall.params.BlogListFront(\r\n" + "	b.id,\r\n"
			+ "	b.creatorHuman.logo,\r\n" + "	b.creatorHuman.nickname,\r\n" + "	b.title,\r\n"
			+ "	b.createTime, b.creatorHuman.id\r\n" + "	\r\n" + "	)\r\n" + "from com.macro.mall.entity.Blog b\r\n"
			+ "where b.blogType.id=?1", countQuery = "select count(1) from Blog b where b.blogType.id=?1  ")
	Page<BlogListFront> searchWithBlogTypeId(String blogTypeId, Pageable page);
	


}
