package com.macro.mall.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.password.Pbkdf2PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class EncryptUtil {

	
	private String key="ZHANG_NING_!!_@@_##";

	private PasswordEncoder encoder;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public PasswordEncoder getEncoder() {
		return encoder;
	}

	public EncryptUtil() {
		this.encoder = new Pbkdf2PasswordEncoder(this.key);
	}
	
	/**
	 * 将一个内容加密
	 * @param content
	 * @return
	 */
	public String encrypt(String content) {
		return this.encoder.encode(content);
	}
	
	/**
	 * 判断两个内容是否是加密和被加密关系，就是第二个参数在解密后是否和第一个参数一致
	 * @param raw_content
	 * @param enc_content
	 * @return
	 */
	public Boolean match(String raw_content, String enc_content) {
		return this.encoder.matches(raw_content, enc_content);
	}
}
