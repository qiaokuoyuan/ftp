package com.macro.mall.entity;

import javax.persistence.Entity;

@Entity
public class DataCube extends BaseEntity {
	
	
	
}
