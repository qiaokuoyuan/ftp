package com.macro.mall.params;

import org.springframework.stereotype.Component;

/**
 * 前台请求数据集详情时返回的数据格式
 * 
 * @author Naga
 *
 */

public class DatasetDetailFront {

	private String id;
	private String title;
	private Double score;
	private Long isCollect;
	private Long collectCount;
	private Long downloadCount;
	private Long datasetSize;
	private String datasetDesc;
	private String datasetTable;
	private String logo;
	private String paperText;

	public DatasetDetailFront() {
		// TODO Auto-generated constructor stub
	}

	public DatasetDetailFront(String id, String title, Double score, Long isCollect, Long collectCount,
			Long downloadCount, Long datasetSize, String datasetDesc, String datasetTable, String logo,
			String paperText) {
		super();
		this.id = id;
		this.title = title;
		this.score = score;
		this.isCollect = isCollect;
		this.collectCount = collectCount;
		this.downloadCount = downloadCount;
		this.datasetSize = datasetSize;
		this.datasetDesc = datasetDesc;
		this.datasetTable = datasetTable;
		this.logo = logo;
		this.paperText = paperText;
	}

	public String getPaperText() {
		return paperText;
	}

	public void setPaperText(String paperText) {
		this.paperText = paperText;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Double getScore() {
		return score;
	}

	public void setScore(Double score) {
		this.score = score;
	}

	public Long getIsCollect() {
		return isCollect;
	}

	public void setIsCollect(Long isCollect) {
		this.isCollect = isCollect;
	}

	public Long getCollectCount() {
		return collectCount;
	}

	public void setCollectCount(Long collectCount) {
		this.collectCount = collectCount;
	}

	public Long getDownloadCount() {
		return downloadCount;
	}

	public void setDownloadCount(Long downloadCount) {
		this.downloadCount = downloadCount;
	}

	public Long getDatasetSize() {
		return datasetSize;
	}

	public void setDatasetSize(Long datasetSize) {
		this.datasetSize = datasetSize;
	}

	public String getDatasetDesc() {
		return datasetDesc;
	}

	public void setDatasetDesc(String datasetDesc) {
		this.datasetDesc = datasetDesc;
	}

	public String getDatasetTable() {
		return datasetTable;
	}

	public void setDatasetTable(String datasetTable) {
		this.datasetTable = datasetTable;
	}

}
