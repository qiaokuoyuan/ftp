package com.macro.mall.cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Component;

@Component
public class ActiveCodeCache {

//	用于验证 验证码是否正确的缓存
	private Map<String, String> cache = new HashMap<>();

//	保存缓存的key，用于清除缓存
	private List<String> keys = new ArrayList<>();

//	最大缓存多少个验证码
	private Integer maxCacheNum = 5;

//	清空一次缓存时 清空掉多少个记录
	private Integer clearCacheNum = 3;

//	根据key生成随机验证码
	public String getRandomCode(String key) {

//		检查缓存是否超标
		if (keys.size() >= maxCacheNum) {

//			清除前 clearCacheNum 个 key
			for (int i = 0; i < clearCacheNum; i++) {
				cache.remove(keys.get(i));
			}
//			修改所有 keys
			keys = keys.subList(clearCacheNum, keys.size() );
		}

		String code = UUID.randomUUID().toString();
		code = code.substring(0, 4);
		cache.put(key, code);
		keys.add(key);
		return code;
	}

	public String getSavedKeyCode(String key) {
		return cache.get(key);
	}

}
