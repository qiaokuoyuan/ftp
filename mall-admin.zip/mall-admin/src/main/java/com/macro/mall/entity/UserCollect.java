package com.macro.mall.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * 用户收藏关系
 * 
 * @author Administrator
 *
 */
@Entity
public class UserCollect {

	@Id
	private String id;

	private String userId;

	private String targetId;

	private String collectType;

	public String getCollectType() {
		return collectType;
	}

	public void setCollectType(String collectType) {
		this.collectType = collectType;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTargetId() {
		return targetId;
	}

	public void setTargetId(String targetId) {
		this.targetId = targetId;
	}

}
