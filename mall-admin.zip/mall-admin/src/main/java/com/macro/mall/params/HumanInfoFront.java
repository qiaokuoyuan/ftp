package com.macro.mall.params;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.macro.mall.entity.Human;
import com.macro.mall.entity.Permission;

//用于前端获取当前用户信息
public class HumanInfoFront {
	private String userId;
	private String username;
	private String nickname;
	private String logo;
	private String frontPermisson;
	private String backPermission;

	
	public HumanInfoFront() {
		// TODO Auto-generated constructor stub
	}
	public HumanInfoFront(String userId, String username, String nickname, String logo, String frontPermisson,
			String backPermission) {
		super();
		this.userId = userId;
		this.username = username;
		this.nickname = nickname;
		this.logo = logo;
		this.frontPermisson = frontPermisson;
		this.backPermission = backPermission;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getFrontPermisson() {
		return frontPermisson;
	}

	public void setFrontPermisson(String frontPermisson) {
		this.frontPermisson = frontPermisson;
	}

	public String getBackPermission() {
		return backPermission;
	}

	public void setBackPermission(String backPermission) {
		this.backPermission = backPermission;
	}

//	从human中获取
	public static HumanInfoFront fromHuman(Human h) {
		HumanInfoFront humanInfoFront = new HumanInfoFront();
		humanInfoFront.setUserId(h.getId());
		humanInfoFront.setUsername(h.getUsername());
		humanInfoFront.setNickname(h.getNickname());
		humanInfoFront.setLogo(h.getLogo());

		List<Permission> permissions = h.getHumanRoles().stream().flatMap(e -> e.getPermissions().stream())
				.collect(Collectors.toList());
		if(permissions.size()>0) {
			
			humanInfoFront
			.setFrontPermisson(permissions.stream().map(e -> e.getFrontUrls()).reduce((a, b) -> a + "," + b).get());
			humanInfoFront
			.setBackPermission(permissions.stream().map(e -> e.getBackUrls()).reduce((a, b) -> a + "," + b).get());
		}else {
			humanInfoFront.setFrontPermisson("");
			humanInfoFront.setBackPermission("");
		}
		return humanInfoFront;
	}

}
