package com.macro.mall.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.macro.mall.entity.TestObject;

public interface BaseRepo  <T extends TestObject> extends JpaRepository<T, String>{

}
