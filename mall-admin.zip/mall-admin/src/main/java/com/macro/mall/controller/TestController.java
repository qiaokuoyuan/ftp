package com.macro.mall.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.macro.mall.entity.TestObject;
import com.macro.mall.jpa.TestRepo;

@RequestMapping("/testController")
@Controller
public class TestController extends BaseController<TestObject> {

	
	@Autowired
	public void setRepo( TestRepo repo) {
		super.setRepo(repo);
	}
	
//	
//	@Autowired
//	private TestRepo testRepo;
//
//	public TestRepo getTestRepo() {
//		return testRepo;
//	}
//
//	public void setTestRepo(TestRepo testRepo) {
//		this.testRepo = testRepo;
//	}
//
//	public TestController() {
//		this.setRepo(testRepo);
//	}
}
