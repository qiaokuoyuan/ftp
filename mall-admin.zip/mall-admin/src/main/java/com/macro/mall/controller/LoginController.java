package com.macro.mall.controller;

import java.util.Base64;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Controller;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.macro.mall.cache.ActiveCodeCache;
import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.Human;
import com.macro.mall.jpa.HumanRepo;
import com.macro.mall.jpa.HumanRoleRepo;
import com.macro.mall.params.HumanInfoFront;
import com.macro.mall.util.BeanTool;
import com.macro.mall.util.EncryptUtil;

@Controller
@RequestMapping("/simpleLogin")
public class LoginController {

	@Autowired
	private EncryptUtil encoder;

	@Autowired
	private HumanRepo humanRepo;

	@Autowired
	private HumanRoleRepo humanRoleRepo;

	@Autowired
	private BeanTool beanTool;

	@Autowired
	private ActiveCodeCache activeCodeCache;

	@Value("${token_name}")
	public String token_name;

	@Value("${key.mall.register}")
	public String key_mall_register;

	public BeanTool getBeanTool() {
		return beanTool;
	}

	public void setBeanTool(BeanTool beanTool) {
		this.beanTool = beanTool;
	}

	public EncryptUtil getEncoder() {
		return encoder;
	}

	public void setEncoder(EncryptUtil encoder) {
		this.encoder = encoder;
	}

	public HumanRoleRepo getHumanRoleRepo() {
		return humanRoleRepo;
	}

	public void setHumanRoleRepo(HumanRoleRepo humanRoleRepo) {
		this.humanRoleRepo = humanRoleRepo;
	}

	public HumanRepo getHumanRepo() {
		return humanRepo;
	}

	public void setHumanRepo(HumanRepo humanRepo) {
		this.humanRepo = humanRepo;
	}

	@RequestMapping("/md5")
	@ResponseBody
	public Object getMd5(String content) throws Exception {

		return new CommonResult().success(beanTool.md5(content));
	}

	/**
	 * 
	 * 发送邮箱验证码
	 * 
	 * @return
	 */
	@RequestMapping("/sendEmailActiveCode")
	@ResponseBody
	public Object sendEmailActiveCode(HttpServletRequest request, HttpServletResponse response, String to) {
		try {

//			使用目标邮箱作为key 生成 随机验证码
			String captcha = activeCodeCache.getRandomCode(to);

//			发送邮件
			beanTool.sendEmail(to, "您的验证码为：" + captcha);
			return new CommonResult().success();

		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}

	}

	/**
	 * 登录
	 * 
	 * @param request
	 * @param response
	 * @param human
	 * @return
	 */
	@RequestMapping("/login")
	@ResponseBody
	public Object login(HttpServletRequest request, HttpServletResponse response, Human human) {
		try {

//			从数据库中获取用户密码
			List<Human> users = humanRepo.findByUsername(human.getUsername());
			if (users.size() > 0) {
				String md5_1 = users.get(0).getPasswordMD5();
				String md5_2 = DigestUtils.md5DigestAsHex(human.getRaw_password().getBytes("utf-8"));
//				如果密码摘要一致，生成加密信息放入token
				if (md5_1.equals(md5_2)) {

//					将用户名加密
					String username_enc = this.encoder.encrypt(human.getUsername());

//					将用户名和加密后的信息 用 base64 存放到cookie中
					String token = Base64.getEncoder()
							.encodeToString((human.getUsername() + "," + username_enc).getBytes());
					return new CommonResult().success("登录成功").addAdditionalAttribute("token", token);
				} else {
					return new CommonResult().failed("密码错误");
				}
			} else {
				return new CommonResult().failed("用户不存在");
			}
		} catch (Exception e) {
			return new CommonResult().failed("登录失败");
		}

	}

	/**
	 * 基于 header 获取当前登录人的信息
	 * 
	 * @param request
	 * @param response
	 * @param human
	 * @return
	 */
	@RequestMapping("/userinfoByHeader")
	@ResponseBody
	public Object userinfoByHeader(HttpServletRequest request) {
		try {
			Human humanByHeader = beanTool.getHumanByHeader(request, token_name);
			return new CommonResult().success(humanByHeader);
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	@RequestMapping("/userinfo")
	@ResponseBody
	public Object userInfo(HttpServletRequest request) {
		try {

			Human humanByHeader = beanTool.getHumanByHeader(request);

			String userid = humanByHeader == null ? "-1" : humanByHeader.getId();

			return new CommonResult().success(humanRepo.getHumanInfoFront(userid));

		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	@RequestMapping("/logout")
	@ResponseBody
	public Object logout(HttpServletRequest request, HttpServletResponse response) {
		try {
			String header = request.getHeader("token-header");
			request.getServletContext().removeAttribute("user-id");
			response.addCookie(new Cookie("token", ""));
			return new CommonResult().success(null);
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 检查注册信息是否有效 （被占用）
	 * 
	 * @param content
	 * @param type
	 * @return
	 */
	@RequestMapping("/registerInfoValid")
	@ResponseBody
	public Object registerInfoValid(String content, String type) {

		Human exampleHuman = new Human();

		if (type.equals("email")) {
			exampleHuman.setEmail(content);
		}

		if (type.equals("username")) {
			exampleHuman.setUsername(content);
		}

		if (type.equals("nickname")) {
			exampleHuman.setNickname(content);
		}

		return new CommonResult().success(humanRepo.exists(Example.of(exampleHuman)));
	}

	/**
	 * 注册
	 * 
	 * @param request
	 * @param response
	 * @param human
	 * @return
	 */
	@RequestMapping("/register")
	@ResponseBody
	public Object register(HttpServletRequest request, Human human, String activeCode) {
		try {

//			检查验证码是有有效
			String savedActiveCode = activeCodeCache.getSavedKeyCode(human.getEmail());
			if (!activeCode.equals(savedActiveCode)) {
				return new CommonResult().failed("验证码无效");
			}

//			检查用户名是否存在
			if (humanRepo.exists(Example.of(new Human().setUsername(human.getUsername())))) {
				return new CommonResult().failed("该用户名已经存在");
			}

//			检查昵称是否存在
			if (humanRepo.exists(Example.of(new Human().setNickname(human.getNickname())))) {
				return new CommonResult().failed("该昵称已经存在");
			}
//			检查邮箱是否存在
			if (humanRepo.exists(Example.of(new Human().setEmail(human.getEmail())))) {
				return new CommonResult().failed("该邮箱已经存在");
			}

//         将传过来的密码值 生成md5
			human.setPasswordMD5(beanTool.md5(human.getRaw_password()));
			human.setId(UUID.randomUUID().toString());
			human.setRaw_password("");

			humanRepo.save(human);
			return new CommonResult().success(human.getId());
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}

	}
}
