package com.macro.mall.params;

public class DatasetListFront {

	private String id;
	private String title;
	private String logo;
	private Long datasetSize;
	private String creatorNickName;
	private String creatorLogo;

	private String creatorId;

	public DatasetListFront() {
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public Long getDatasetSize() {
		return datasetSize;
	}

	public void setDatasetSize(Long datasetSize) {
		this.datasetSize = datasetSize;
	}

	public String getCreatorNickName() {
		return creatorNickName;
	}

	public void setCreatorNickName(String creatorNickName) {
		this.creatorNickName = creatorNickName;
	}

	public String getCreatorLogo() {
		return creatorLogo;
	}

	public void setCreatorLogo(String creatorLogo) {
		this.creatorLogo = creatorLogo;
	}

	public DatasetListFront(String id, String title, String logo, Long datasetSize, String creatorNickName,
			String creatorLogo, String creatorId) {
		super();
		this.id = id;
		this.title = title;
		this.logo = logo;
		this.datasetSize = datasetSize;
		this.creatorNickName = creatorNickName;
		this.creatorLogo = creatorLogo;
		this.creatorId = creatorId;
	}

}
