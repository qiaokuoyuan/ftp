package com.macro.mall.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedEntityGraph;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
public class Permission extends BaseEntity {

	@ManyToMany(fetch = FetchType.LAZY, mappedBy = "permissions", cascade = CascadeType.DETACH)
	@JsonIgnore
	private List<HumanRole> humanRoles;

//	权限的名称
	private String name;

	// 当前 许可 前端可以访问的地址(用逗号隔开)
	@Column(columnDefinition = "TEXT")
	private String frontUrls;

//	当前 许可 后端可以访问的 接口集合
	@Column(columnDefinition = "TEXT")
	private String backUrls;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFrontUrls() {
		return frontUrls;
	}

	public void setFrontUrls(String frontUrls) {
		this.frontUrls = frontUrls;
	}

	public String getBackUrls() {
		return backUrls;
	}

	public void setBackUrls(String backUrls) {
		this.backUrls = backUrls;
	}

	public List<HumanRole> getHumanRoles() {
		return humanRoles;
	}

	public void setHumanRoles(List<HumanRole> humanRoles) {
		this.humanRoles = humanRoles;
	}

	public Permission() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Permission [name=" + name + ", frontUrls=" + frontUrls + ", backUrls=" + backUrls + "]";
	}

}
