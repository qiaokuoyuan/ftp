package com.macro.mall.enu;

public enum RateType {
	DATASET_RATE, COMMENT_RATE,SOLUTION_RATE
}
