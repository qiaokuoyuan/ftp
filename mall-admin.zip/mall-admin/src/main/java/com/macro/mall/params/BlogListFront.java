package com.macro.mall.params;

import java.util.Date;

public class BlogListFront {

	private String id;
	private String creatorLogo;
	private String creatorNickname;
	private String title;
	private Date createTime;
	private String creatorId;

	public BlogListFront() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatorLogo() {
		return creatorLogo;
	}

	public void setCreatorLogo(String creatorLogo) {
		this.creatorLogo = creatorLogo;
	}

	public String getCreatorNickname() {
		return creatorNickname;
	}

	public void setCreatorNickname(String creatorNickname) {
		this.creatorNickname = creatorNickname;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public BlogListFront(String id, String creatorLogo, String creatorNickname, String title, Date createTime) {
		this.id = id;
		this.creatorLogo = creatorLogo;
		this.creatorNickname = creatorNickname;
		this.title = title;
		this.createTime = createTime;
	}

	public BlogListFront(String id, String creatorLogo, String creatorNickname, String title, Date createTime,
			String creatorId) {
		this.id = id;
		this.creatorLogo = creatorLogo;
		this.creatorNickname = creatorNickname;
		this.title = title;
		this.createTime = createTime;

		this.creatorId = creatorId;
	}
}
