package com.macro.mall.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.Human;
import com.macro.mall.entity.HumanRole;
import com.macro.mall.entity.Permission;
import com.macro.mall.jpa.HumanRepo;
import com.macro.mall.jpa.HumanRoleRepo;
import com.macro.mall.jpa.PermissionRepo;
import com.macro.mall.params.RoleBackWithPermission;

@RequestMapping("/humanRole")
@Component
@Controller
public class HumanRoleController extends BaseController<HumanRole> {

	@Autowired
	private HumanRoleRepo humanRoleRepo;

	@Autowired
	private HumanRepo humanRepo;

	@Autowired
	private PermissionRepo permissionRepo;

	public HumanRepo getHumanRepo() {
		return humanRepo;
	}

	public void setHumanRepo(HumanRepo humanRepo) {
		this.humanRepo = humanRepo;
	}

	public PermissionRepo getPermissionRepo() {
		return permissionRepo;
	}

	public void setPermissionRepo(PermissionRepo permissionRepo) {
		this.permissionRepo = permissionRepo;
	}

	public HumanRoleRepo getHumanRoleRepo() {
		return humanRoleRepo;
	}

	public void setHumanRoleRepo(HumanRoleRepo humanRoleRepo) {
		this.humanRoleRepo = humanRoleRepo;
	}

	@Autowired
	public void setRepo() {
		this.setRepo(this.humanRoleRepo);
	}

	/**
	 * 从后台直接添加或者编辑角色
	 * 
	 * @param role          角色的example
	 * @param permissionIds 角色允许访问的permission的id集合
	 * @return
	 */
	@RequestMapping("/addRoleBack")
	@ResponseBody
	public Object addRoleBack(HttpServletRequest request, HttpServletResponse response, HumanRole role,
			String permissionIds) {
		try {
			List<String> ids = Arrays.asList(permissionIds.split(","));
			List<Permission> permissions = ids.stream().map(e -> permissionRepo.findOne(e))
					.collect(Collectors.toList());

			role.setPermissions(permissions);

//			如果没有id，生成id
			if (StringUtils.isEmpty(role.getId())) {
				return super.add(request, response, role);
			} else {
				return super.update(role);
			}
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 从后台删除 一个 角色
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/delBack")
	@ResponseBody
	@Transactional
	public Object delBack(String id) {
		try {
			HumanRole role = humanRoleRepo.findOne(id);

			// 首先清除当前 角色具有的 permissionRepo 关联
			List<Permission> permissions = role.getPermissions();
			permissions.forEach(p -> p.getHumanRoles().removeIf(r -> {
				return r.getId().equals(id);
			}));

//			删除用户关联关系
			List<Human> humans = role.getHumans();
			humans.forEach(h -> h.getHumanRoles().removeIf(r -> {
				return r.getId().equals(id);
			}));

//			保存关系
			permissionRepo.save(permissions);
			humanRepo.save(humans);

//			删除角色
			super.del(id);
			
			return new CommonResult().success("删除成功");

		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 获取后台 角色管理的 列表
	 * 
	 * @param example
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	@RequestMapping("/getRoleBackWithPermission")
	@ResponseBody
	public Object getRoleBackWithPermission(HumanRole example, @RequestParam(defaultValue = "1") Integer pageIndex,
			@RequestParam(defaultValue = "10") Integer pageSize) {
		try {
			--pageIndex;
			Page<HumanRole> roles = humanRoleRepo.findAll(Example.of(example), new PageRequest(pageIndex, pageSize));
			List<RoleBackWithPermission> rps = roles.getContent().stream().map(r -> {
				RoleBackWithPermission rPermission = new RoleBackWithPermission();
				rPermission.setPermissions(r.getPermissions());
				rPermission.setName(r.getRoleName());
				rPermission.setRoleId(r.getId());
				return rPermission;
			}).collect(Collectors.toList());

			return new CommonResult().success(rps).addAdditionalAttribute("total", roles.getTotalElements());
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}
}
