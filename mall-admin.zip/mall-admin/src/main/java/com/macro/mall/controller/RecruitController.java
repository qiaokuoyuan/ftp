package com.macro.mall.controller;

import java.util.Enumeration;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.Company;
import com.macro.mall.entity.Recruit;
import com.macro.mall.jpa.CompanyRepo;
import com.macro.mall.jpa.RecruitRepo;

/**
 * 招聘信息控制器
 * 
 * @author Armageddon
 *
 */
@RequestMapping("/recruit")
@Controller
public class RecruitController extends BaseController<Recruit> {
	
	@Autowired
	private RecruitRepo recruitRepo;
	
	@Autowired
	private CompanyRepo companyRepo;

	
	
	public CompanyRepo getCompanyRepo() {
		return companyRepo;
	}

	public void setCompanyRepo(CompanyRepo companyRepo) {
		this.companyRepo = companyRepo;
	}

	public RecruitRepo getRecruitRepo() {
		return recruitRepo;
	}

	public void setRecruitRepo(RecruitRepo recruitRepo) {
		this.recruitRepo = recruitRepo;
	}
	
	@Autowired
	public void setRepo() {
		this.setRepo(this.recruitRepo);
	}
	

	@Override
	public Object add(HttpServletRequest request, HttpServletResponse response, Recruit t) {
		
		Enumeration<String> parameterNames = request.getParameterNames();
		
		while (parameterNames.hasMoreElements()) {
			String paraName=parameterNames.nextElement();
			System.err.println(paraName);
		}
		
		String companyId=request.getParameter("companyId");
		
//		获取公司参数		
		Company company = companyRepo.findOne(companyId);
		
		if(company !=null) {
			t.setCompany(company);
			return super.add(request, response, t);
		}else {
			return new CommonResult().failed("公司id无效");
		}
		
	}
	
	
	
	
	
	

}
