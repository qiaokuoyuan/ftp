package com.macro.mall.controller;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.HumanRole;
import com.macro.mall.entity.Permission;
import com.macro.mall.jpa.HumanRoleRepo;
import com.macro.mall.jpa.PermissionRepo;
import com.macro.mall.params.PermissionBackWithRoleName;
import com.macro.mall.util.BeanTool;

@Controller
@Component
@RequestMapping("/permission")
public class PermissionController extends BaseController<Permission> {

	@Autowired
	private PermissionRepo permissionRepo;

	@Autowired
	private HumanRoleRepo humanRoleRepo;

	@Autowired
	public void setRepo() {
		this.setRepo(this.permissionRepo);
	}

	public HumanRoleRepo getHumanRoleRepo() {
		return humanRoleRepo;
	}

	public void setHumanRoleRepo(HumanRoleRepo humanRoleRepo) {
		this.humanRoleRepo = humanRoleRepo;
	}

	public PermissionRepo getPermissionRepo() {
		return permissionRepo;
	}

	public void setPermissionRepo(PermissionRepo permissionRepo) {
		this.permissionRepo = permissionRepo;
	}

	/**
	 * 后台管理中删除一个permission
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/delBack")
	@ResponseBody
	@Transactional
	public Object delBack(String id) {
		try {
//			首先从数据库中取出当前的 permission
			Permission permission = permissionRepo.findOne(id);

//			从所有管理的角色中 删除当前 permission
			List<HumanRole> humanRoles = permission.getHumanRoles();
			humanRoles.stream().forEach(e -> {
				e.getPermissions().removeIf(p -> p.getId().equals(id));
			});

//			先将 修改后的角色信息保存
			humanRoleRepo.save(humanRoles);
			super.del(id);
			return new CommonResult().success("删除成功");

		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return new CommonResult().failed(e.getMessage());
		}
	}

	@RequestMapping("/getPermissionBackWithRoleName")
	@ResponseBody
	public Object getPermissionBackWithRoleName(Permission example, @RequestParam(defaultValue = "1") Integer pageIndex,
			@RequestParam(defaultValue = "10") Integer pageSize) {
		try {
			--pageIndex;
			Page<Permission> permissions = permissionRepo.findAll(Example.of(example),
					new PageRequest(pageIndex, pageSize));
			List<PermissionBackWithRoleName> permissionBackWithRoleNames = permissions.getContent().stream().map(p -> {
				PermissionBackWithRoleName pBackWithRoleName = new PermissionBackWithRoleName();
				pBackWithRoleName.setId(p.getId());
				pBackWithRoleName.setName(p.getName());
				pBackWithRoleName.setFrontUrls(p.getFrontUrls());
				pBackWithRoleName.setBackUrls(p.getBackUrls());
				pBackWithRoleName.setRoleNames(
						p.getHumanRoles().stream().map(r -> r.getRoleName()).collect(Collectors.toList()));

				return pBackWithRoleName;
			}).collect(Collectors.toList());
			return new CommonResult().success(permissionBackWithRoleNames).addAdditionalAttribute("total",
					permissions.getTotalElements());
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}

	}
}
