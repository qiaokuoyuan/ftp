package com.macro.mall.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.macro.mall.entity.Comment;
import com.macro.mall.entity.Comment2;

@Component
public interface CommentRepo2 extends JpaRepository<Comment2, String> {

	List<Comment> findByTargetId(String targetId);

}
