package com.macro.mall.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//用户收藏关系
@Entity
@Table(name = "collect")
public class Collect {

	@Column(name = "id")
	@Id
	private String id;

	@Column(name = "user_id")
	private String userid;

	@Column(name = "target_id")
	private String targetId;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getTargetId() {
		return targetId;
	}

	public void setTargetId(String targetId) {
		this.targetId = targetId;
	}

}
