package com.macro.mall.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.springframework.stereotype.Component;

@Component
@Entity
public class Dataset extends BaseEntity {

	private String title = "";
	private String subTitle = "";
	private String datasetTypeId = "";
	private Long dataSize = 0L;
	private String logo = "";
	private String fileCode = "";
	private String netDiskUrl = "";
	private String netDiskPassword = "";

//	数据存储位置（netdisk；baiduyun）
	private String dataStorePlace = "";

	@Column(columnDefinition = "TEXT")
	private String paperText = "";

	@Column(columnDefinition = "TEXT")
	private String dataDesc = "";

	@Column(columnDefinition = "TEXT")
	private String dataTable = "";

	@Column(columnDefinition = "TEXT")
	private String paperDesc = "";

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSubTitle() {
		return subTitle;
	}

	public void setSubTitle(String subTitle) {
		this.subTitle = subTitle;
	}

	public String getDatasetTypeId() {
		return datasetTypeId;
	}

	public void setDatasetTypeId(String datasetTypeId) {
		this.datasetTypeId = datasetTypeId;
	}

	public Long getDataSize() {
		return dataSize;
	}

	public void setDataSize(Long dataSize) {
		this.dataSize = dataSize;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getFileCode() {
		return fileCode;
	}

	public void setFileCode(String fileCode) {
		this.fileCode = fileCode;
	}

	public String getNetDiskUrl() {
		return netDiskUrl;
	}

	public void setNetDiskUrl(String netDiskUrl) {
		this.netDiskUrl = netDiskUrl;
	}

	public String getNetDiskPassword() {
		return netDiskPassword;
	}

	public void setNetDiskPassword(String netDiskPassword) {
		this.netDiskPassword = netDiskPassword;
	}

	public String getDataStorePlace() {
		return dataStorePlace;
	}

	public void setDataStorePlace(String dataStorePlace) {
		this.dataStorePlace = dataStorePlace;
	}

	public String getPaperText() {
		return paperText;
	}

	public void setPaperText(String paperText) {
		this.paperText = paperText;
	}

	public String getDataDesc() {
		return dataDesc;
	}

	public void setDataDesc(String dataDesc) {
		this.dataDesc = dataDesc;
	}

	public String getDataTable() {
		return dataTable;
	}

	public void setDataTable(String dataTable) {
		this.dataTable = dataTable;
	}

	public String getPaperDesc() {
		return paperDesc;
	}

	public void setPaperDesc(String paperDesc) {
		this.paperDesc = paperDesc;
	}

}
