package com.macro.mall.controller;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.Human;
import com.macro.mall.entity.HumanRole;
import com.macro.mall.jpa.HumanRepo;
import com.macro.mall.jpa.HumanRoleRepo;
import com.macro.mall.params.HumanPermissionString;
import com.macro.mall.params.HumanRole_id_name_touristavailable;
import com.macro.mall.util.BeanTool;

@Controller
@Component
@RequestMapping("/webConfig")
public class WebConfigController {

	@Autowired
	private HumanRepo humanRepo;

	@Autowired
	private HumanRoleRepo humanRoleRepo;

	@Autowired
	private BeanTool beanTool;

	public BeanTool getBeanTool() {
		return beanTool;
	}

	public void setBeanTool(BeanTool beanTool) {
		this.beanTool = beanTool;
	}

	public HumanRepo getHumanRepo() {
		return humanRepo;
	}

	public void setHumanRepo(HumanRepo humanRepo) {
		this.humanRepo = humanRepo;
	}

	public HumanRoleRepo getHumanRoleRepo() {
		return humanRoleRepo;
	}

	public void setHumanRoleRepo(HumanRoleRepo humanRoleRepo) {
		this.humanRoleRepo = humanRoleRepo;
	}

	/**
	 * 获取游客的角色集合
	 * 
	 * @param toTourist ： available 游客角色 unavailable 非游客权限 all 所有权限
	 * @return
	 */
	@RequestMapping("/getRoles")
	@ResponseBody
	public Object getRoles(String toTourist) {

		try {

			List<HumanRole> findAll = null;

			if (toTourist.equals("available")) {
//				如过是游客角色
				HumanRole role_exampleHumanRole = new HumanRole();
				role_exampleHumanRole.setAvaliableToTourist(true);
				findAll = humanRoleRepo.findAll(Example.of(role_exampleHumanRole));
			} else if (toTourist.equals("unavailable")) {

//				如过是非游客角色
				HumanRole role_exampleHumanRole = new HumanRole();
				role_exampleHumanRole.setAvaliableToTourist(false);
				findAll = humanRoleRepo.findAll(Example.of(role_exampleHumanRole));
			} else if (toTourist.equals("all")) {

//				如果是所有角色
				findAll = humanRoleRepo.findAll();
			} else {
				return new CommonResult().failed("参数 toTourist 无效");
			}

			List<HumanRole_id_name_touristavailable> roles = findAll
					.stream().map(e -> new HumanRole_id_name_touristavailable().setId(e.getId())
							.setName(e.getRoleName()).setTouristAvailable(e.getAvaliableToTourist()))
					.collect(Collectors.toList());
			return new CommonResult().success(roles);
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 将一个角色设置为游客可以使用
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/addTouristRole")
	@ResponseBody
	public Object addTouristRole(String id) {
		try {
			HumanRole findOne = humanRoleRepo.findOne(id);
			findOne.setAvaliableToTourist(true);
			humanRoleRepo.save(findOne);
			return new CommonResult().success("修改成功");
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 将一个角色设置为游客 不可使用
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/delTouristRole")
	@ResponseBody
	public Object delTouristRole(String id) {
		try {
			HumanRole findOne = humanRoleRepo.findOne(id);
			findOne.setAvaliableToTourist(false);
			humanRoleRepo.save(findOne);
			return new CommonResult().success("修改成功");
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 获取当前用户前端和后端可以访问的地址集合
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping("/getFrotPermissionStringBackPermissionString")
	@ResponseBody
	public Object getFrotPermissionStringBackPermissionString(HttpServletRequest request) {
		try {

//			尝试获取当前登陆用户
			Human humanByHeader = beanTool.getHumanByHeader(request);

			List<HumanPermissionString> humanPermissionString = null;

			if (humanByHeader == null) {
//				如过未获取到用户，设置 用户id为-1
				humanPermissionString = humanRepo.getHumanPermissionString("-1");
			} else {
//				如过获取到了用户，设置用户id
				humanPermissionString = humanRepo.getHumanPermissionString(humanByHeader.getId());
			}

			return new CommonResult().success(humanPermissionString);
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}
}
