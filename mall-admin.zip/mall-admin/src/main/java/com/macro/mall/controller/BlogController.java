package com.macro.mall.controller;

import java.util.Date;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.Blog;
import com.macro.mall.entity.BlogType;
import com.macro.mall.entity.Human;
import com.macro.mall.jpa.BlogRepo;
import com.macro.mall.jpa.BlogTypeRepo;
import com.macro.mall.util.BeanTool;

@RequestMapping("/blog")
@Controller
public class BlogController extends LoginController {

	@Autowired
	private BeanTool beanTool;

	@Autowired
	private HttpServletRequest request;

	@Autowired
	private HttpServletResponse response;
	@Autowired
	private BlogRepo blogRepo;

	@Autowired
	private BlogTypeRepo blogTypeRepo;

	public HttpServletRequest getRequest() {
		return request;
	}

	public BeanTool getBeanTool() {
		return beanTool;
	}

	public void setBeanTool(BeanTool beanTool) {
		this.beanTool = beanTool;
	}

	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}

	public BlogTypeRepo getBlogTypeRepo() {
		return blogTypeRepo;
	}

	public void setBlogTypeRepo(BlogTypeRepo blogTypeRepo) {
		this.blogTypeRepo = blogTypeRepo;
	}

	public BlogRepo getBlogRepo() {
		return blogRepo;
	}

	public void setBlogRepo(BlogRepo blogRepo) {
		this.blogRepo = blogRepo;
	}

	/**
	 * 添加blog
	 * 
	 * @return
	 */
	@RequestMapping("/addBlog")
	@ResponseBody
	public Object addBlog(HttpServletRequest request, Blog blog) {
		try {

			Human human = beanTool.getHumanByHeader(request);
			blog.setCreatorHuman(human);
			blog.setId(UUID.randomUUID().toString());
			blog.setCreateTime(new Date());
			blogRepo.save(blog);
			return new CommonResult().success(blog.getId());
		} catch (Exception e) {
			return new CommonResult().success(e.getMessage());
		}
	}

	/**
	 * 删除一个
	 * 
	 * @param blogId
	 * @return
	 */
	@RequestMapping("/delBlog")
	@ResponseBody
	public Object delBlog(String blogId) {
		try {
			blogRepo.delete(blogId);
			return new CommonResult().success("删除成功");
		} catch (Exception e) {
			return new CommonResult().success(e.getMessage());
		}
	}

	/**
	 * 编辑一个blog
	 * 
	 * @param id
	 * @param title
	 * @param content
	 * @return
	 */
	@RequestMapping("/updateBlog")
	@ResponseBody
	public Object updateBlog(Blog blog, String blogTypeId) {
		try {

//			找出旧的 blog

			Blog oldBlog = blogRepo.findOne(blog.getId());

			oldBlog.setBlogType(blogTypeRepo.findOne(blogTypeId));

			beanTool.unNullCopy(oldBlog, blog);

//			blogRepo.save(oldBlog);
			blogRepo.saveAndFlush(oldBlog);
			return new CommonResult().success("编辑成功");
		} catch (Exception e) {
			return new CommonResult().success(e.getMessage());
		}
	}

	@RequestMapping("/getBlogByTarget")
	@ResponseBody
	public Object getBlogByTarget(String targetId, @RequestParam(required = false) String blogType,
			@RequestParam(defaultValue = "1", required = false) Integer pageIndex,
			@RequestParam(defaultValue = "20", required = false) Integer pageSize) {
		try {
//			参数检查			
			if (pageSize > 100) {
				return new CommonResult().failed("分页太大");
			}
			if (pageIndex < 1) {
				return new CommonResult().failed("页码太小");
			}

			Pageable page = new PageRequest(pageIndex - 1, pageSize);

			Blog example = new Blog();
			example.setTargetId(targetId);

//			如果指定了blogtype
			if (!StringUtils.isEmpty(blogType)) {
				BlogType blogTypeObj = blogTypeRepo.findOne(blogType);
				example.setBlogType(blogTypeObj);
			}

			Page<Blog> blogs = blogRepo.findAll(Example.of(example), page);

			return new CommonResult().success(blogs);
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	@RequestMapping("/getBlog")
	@ResponseBody
	public Object getBlog(String blogId) {
		try {
			return new CommonResult().success(blogRepo.findOne(blogId));
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 获取所有的blog
	 * 
	 * @return
	 */
	@RequestMapping("/getBlogs")
	@ResponseBody
	public Object getBlogs(@RequestParam(defaultValue = "1") Integer pageIndex,
			@RequestParam(defaultValue = "10") Integer pageSize, String blogTypeId, String keyword) {
		try {
			--pageIndex;
//			生成分页
			Pageable page = new PageRequest(pageIndex, pageSize);

//			如果 类型和关键词都是空
			if (StringUtils.isEmpty(blogTypeId) && StringUtils.isEmpty(keyword)) {
				return new CommonResult().success(blogRepo.search(page));
			}

//			如果类型不是空，关键词是空
			if (!StringUtils.isEmpty(blogTypeId) && StringUtils.isEmpty(keyword)) {
				return new CommonResult().success(blogRepo.searchWithBlogTypeId(blogTypeId, page));
			}

			return new CommonResult().failed("参数错误");

		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}
}
