package com.macro.mall.enu;

public class UserCollectType {
//	收藏数据集
	public static String DATA_COLLECT = "DATA_COLLECT";
//	收藏solution
	public static String SOLUTION_COLLECT = "SOLUTION_COLLECT";
//	收藏评论
	public static String COMMENT_COLLECT = "COMMENT_COLLECT";
//	收藏招聘
	public static String RECRUIT_COLLECT = "RECRUIT_COLLECT";

	public static String typeStrs() {
		return UserCollectType.DATA_COLLECT + "," + UserCollectType.SOLUTION_COLLECT + ","
				+ UserCollectType.COMMENT_COLLECT + "," + UserCollectType.RECRUIT_COLLECT;
	}

	/**
	 * 检查传入的字段是否有效
	 * 
	 * @return
	 */
	public static Boolean typeAvaliable(String type) {
		String typeStr = UserCollectType.typeStrs();
		if (typeStr.indexOf(type) >= 0) {
			return true;
		} else {
			return false;
		}
	}
}
