package com.macro.mall.params;

/**
 * 前端列表 时使用的 对象
 * 
 * @author Naga
 *
 */
public class SolutionListItem {

	private String logo;
	private String creatorId;
	private String creatorNickName;
	private String creatorLogo;
	private String competitionName;
	private String solutionTitle;
	private Integer solutionRank;
	private Integer solutionTop;

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public String getCreatorNickName() {
		return creatorNickName;
	}

	public void setCreatorNickName(String creatorNickName) {
		this.creatorNickName = creatorNickName;
	}

	public String getCreatorLogo() {
		return creatorLogo;
	}

	public void setCreatorLogo(String creatorLogo) {
		this.creatorLogo = creatorLogo;
	}

	public String getCompetitionName() {
		return competitionName;
	}

	public void setCompetitionName(String competitionName) {
		this.competitionName = competitionName;
	}

	public String getSolutionTitle() {
		return solutionTitle;
	}

	public void setSolutionTitle(String solutionTitle) {
		this.solutionTitle = solutionTitle;
	}

	public Integer getSolutionRank() {
		return solutionRank;
	}

	public void setSolutionRank(Integer solutionRank) {
		this.solutionRank = solutionRank;
	}

	public Integer getSolutionTop() {
		return solutionTop;
	}

	public void setSolutionTop(Integer solutionTop) {
		this.solutionTop = solutionTop;
	}

	public SolutionListItem(String logo, String creatorId, String creatorNickName, String creatorLogo,
			String competitionName, String solutionTitle, Integer solutionRank, Integer solutionTop) {
		super();
		this.logo = logo;
		this.creatorId = creatorId;
		this.creatorNickName = creatorNickName;
		this.creatorLogo = creatorLogo;
		this.competitionName = competitionName;
		this.solutionTitle = solutionTitle;
		this.solutionRank = solutionRank;
		this.solutionTop = solutionTop;
	}
}
