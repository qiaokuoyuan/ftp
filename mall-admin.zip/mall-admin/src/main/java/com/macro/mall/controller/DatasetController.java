package com.macro.mall.controller;

import java.util.Date;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.Dataset;
import com.macro.mall.entity.Human;
import com.macro.mall.jpa.DatasetRepo;
import com.macro.mall.jpa.DatasetTypeRepo;
import com.macro.mall.params.DatasetListFront;
import com.macro.mall.params.EditDatasetDetail;
import com.macro.mall.util.BeanTool;

@RequestMapping("/dataset")
@Controller
@CrossOrigin
public class DatasetController extends BaseController<Dataset> {

	@Autowired
	private DatasetTypeRepo datasetTypeRepo;

	@Autowired
	private DatasetRepo datasetRepo;

	@Autowired
	private BeanTool beanTool;

	@Autowired
	public void setRepo() {
		this.setRepo(datasetRepo);
	}

	public DatasetRepo getDatasetRepo() {
		return datasetRepo;
	}

	public void setDatasetRepo(DatasetRepo datasetRepo) {
		this.datasetRepo = datasetRepo;
	}

	public BeanTool getBeanTool() {
		return beanTool;
	}

	public void setBeanTool(BeanTool beanTool) {
		this.beanTool = beanTool;
	}

	/**
	 * 添加数据集
	 */
	@RequestMapping("/addDataset")
	@ResponseBody
	public Object addDataset(HttpServletRequest request, Dataset dataSet) {
		try {

//			如果有id，是更新
			if (StringUtils.isEmpty(dataSet.getId())) {
				dataSet.setCreateTime(new Date());
				dataSet.setId(UUID.randomUUID().toString());
				Human human = beanTool.getHumanByHeader(request);
				dataSet.setCreatorHuman(human);
				datasetRepo.save(dataSet);
				return new CommonResult().success(dataSet.getId());
			} else {
				update(dataSet);
				return new CommonResult().success("更新成功");
			}

		} catch (Exception e) {
			return new CommonResult().failed();
		}
	}

	/**
	 * 获取一个数据集的详情
	 * 
	 * @param request
	 * @param id
	 * @return
	 */
	@RequestMapping("/dataDetail")
	@ResponseBody
	public Object detail(HttpServletRequest request, String id) {
		try {

			Human user = beanTool.getHumanByHeader(request, token_name);
			if (user == null) {
				return new CommonResult().failed("您未登陆");
			} else {
				Object detail = datasetRepo.detail(id, user.getId());
				return new CommonResult().success(detail);
			}

		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

//	根据关键词和类型id搜索
	@RequestMapping("/search")
	@ResponseBody
	public Object search(String keyword, String datasetTypeId, @RequestParam(defaultValue = "1") Integer pageIndex,
			@RequestParam(defaultValue = "10") Integer pageSize) {
		try {

			--pageIndex;
			Pageable pageable = new PageRequest(pageIndex, pageSize);
			Page<DatasetListFront> search = datasetRepo.search(keyword, datasetTypeId, pageable);

//			Object search = datasetRepo.test(keyword);

			return new CommonResult().success(search);

		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

}
