package com.macro.mall.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class WebConfig {

	@Id
	private String id;

//	未登陆用户可以访问的接口集合
	@Column(columnDefinition = "TEXT")
	private String touristBackPermission;

//	未登陆用户可以访问的前端地址集合
	@Column(columnDefinition = "TEXT")
	private String touristFrontPermission;

//首页底部背景图地址
	private String footerBackGroundImgSrc;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTouristBackPermission() {
		return touristBackPermission;
	}

	public void setTouristBackPermission(String touristBackPermission) {
		this.touristBackPermission = touristBackPermission;
	}

	public String getTouristFrontPermission() {
		return touristFrontPermission;
	}

	public void setTouristFrontPermission(String touristFrontPermission) {
		this.touristFrontPermission = touristFrontPermission;
	}

	public String getFooterBackGroundImgSrc() {
		return footerBackGroundImgSrc;
	}

	public void setFooterBackGroundImgSrc(String footerBackGroundImgSrc) {
		this.footerBackGroundImgSrc = footerBackGroundImgSrc;
	}

}
