package com.macro.mall.component;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.Human;
import com.macro.mall.jpa.HumanRepo;
import com.macro.mall.params.HumanPermissionString;
import com.macro.mall.util.BeanTool;

/**
 * HibernateValidator错误结果处理切面 Created by macro on 2018/4/26.
 */

@Aspect
@Component
@Order(1)
public class PermissionCheck {

	@Autowired
	private BeanTool beanTool;

	@Autowired
	private HumanRepo humanRepo;

	public HumanRepo getHumanRepo() {
		return humanRepo;
	}

	public void setHumanRepo(HumanRepo humanRepo) {
		this.humanRepo = humanRepo;
	}

	public BeanTool getBeanTool() {
		return beanTool;
	}

	public void setBeanTool(BeanTool beanTool) {
		this.beanTool = beanTool;
	}

	@Pointcut("execution(public * com.macro.mall.controller.*.*(..))")
	public void BindingResult() {
	}

	@Around("BindingResult()")
	public Object doAround(ProceedingJoinPoint joinPoint) throws Throwable {

		// 获取当前请求对象
		ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
		HttpServletRequest request = attributes.getRequest();

		String api = request.getRequestURI();

		Human human = beanTool.getHumanByHeader(request);

//		如果当前用户为 superman，直接放行
		if (human!= null && human.getIsSuperman()) {
			System.err.println("用户" + human.getId() + "是 superman 直接放行");
			return joinPoint.proceed();
		}
		
		String human_id=human==null?"":human.getId();
		
//		获取当前用户的权限集合
		List<HumanPermissionString> humanPermissionString = humanRepo.getHumanPermissionString(human_id);

//		检查权限
		boolean anyMatch = humanPermissionString.stream().anyMatch(e -> {
			return e.getBackPermissionString().indexOf(api) >= 0;
		});

//		检查权限
		if (anyMatch) {
			return joinPoint.proceed();
		} else {
			return new CommonResult().failed("您的权限不足");
		}

	}
}
