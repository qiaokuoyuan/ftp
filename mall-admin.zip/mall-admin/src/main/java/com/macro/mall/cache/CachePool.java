package com.macro.mall.cache;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

//缓存对象
@Component
public class CachePool<V extends Object, K extends Serializable> {

	private Map<K, V> poolMap;
	private Map<K, Date> cacheDate;

//	id的字段名
	private String idName = "";

	public String getIdName() {
		return idName;
	}

	public CachePool() {
		this.poolMap = new HashMap<>();
		cacheDate = new HashMap<>();
	}

//	缓存一个对象
	public void cache(K k, V v) throws Exception {
		poolMap.put(k, v);
		cacheDate.put(k, new Date());
	}

	public V get(K k) {
		return poolMap.get(k);
	}
}
