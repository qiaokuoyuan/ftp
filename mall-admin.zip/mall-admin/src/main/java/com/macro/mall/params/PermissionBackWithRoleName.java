package com.macro.mall.params;

import java.util.List;

public class PermissionBackWithRoleName {

	private String id;
	private String frontUrls;
	private String backUrls;
	private List<String> roleNames;
	private String name;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFrontUrls() {
		return frontUrls;
	}

	public void setFrontUrls(String frontUrls) {
		this.frontUrls = frontUrls;
	}

	public String getBackUrls() {
		return backUrls;
	}

	public void setBackUrls(String backUrls) {
		this.backUrls = backUrls;
	}

	public List<String> getRoleNames() {
		return roleNames;
	}

	public void setRoleNames(List<String> roleNames) {
		this.roleNames = roleNames;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public PermissionBackWithRoleName() {
		super();
		// TODO Auto-generated constructor stub
	}

}
