package com.macro.mall.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.springframework.stereotype.Component;

@Component
@Entity
public class Solution extends BaseEntity {

	private String solutionTitle;
	private Integer solutionRank;
	private Integer solutionTop;
	private Date createTime;
	private String content;
	private String logo;

	private String solutionFrom;

	private String competitionId;

	public String getCompetitionId() {
		return competitionId;
	}

	public void setCompetitionId(String competitionId) {
		this.competitionId = competitionId;
	}

	public String getSolutionFrom() {
		return solutionFrom;
	}

	public void setSolutionFrom(String solutionFrom) {
		this.solutionFrom = solutionFrom;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getSolutionTitle() {
		return solutionTitle;
	}

	public void setSolutionTitle(String solutionTitle) {
		this.solutionTitle = solutionTitle;
	}

	public Integer getSolutionRank() {
		return solutionRank;
	}

	public void setSolutionRank(Integer solutionRank) {
		this.solutionRank = solutionRank;
	}

	public Integer getSolutionTop() {
		return solutionTop;
	}

	public void setSolutionTop(Integer solutionTop) {
		this.solutionTop = solutionTop;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

}
