package com.macro.mall.params;

public class EditDatasetDetail {
	private String id;
	private String datasetTypeId;
	private String title;
	private String subTitle;
	private Long dataSize;
	private String logo;
	private String dataDesc;
	private String dataTable;
	private String fileCode;
	private String fileName;
	private String dataStorePlace;
	private String netDiskUrl;
	private String netDiskPassword;

	public EditDatasetDetail() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDatasetTypeId() {
		return datasetTypeId;
	}

	public void setDatasetTypeId(String datasetTypeId) {
		this.datasetTypeId = datasetTypeId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSubTitle() {
		return subTitle;
	}

	public void setSubTitle(String subTitle) {
		this.subTitle = subTitle;
	}

	public Long getDataSize() {
		return dataSize;
	}

	public void setDataSize(Long dataSize) {
		this.dataSize = dataSize;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getDataDesc() {
		return dataDesc;
	}

	public void setDataDesc(String dataDesc) {
		this.dataDesc = dataDesc;
	}

	public String getDataTable() {
		return dataTable;
	}

	public void setDataTable(String dataTable) {
		this.dataTable = dataTable;
	}

	public String getFileCode() {
		return fileCode;
	}

	public void setFileCode(String fileCode) {
		this.fileCode = fileCode;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getDataStorePlace() {
		return dataStorePlace;
	}

	public void setDataStorePlace(String dataStorePlace) {
		this.dataStorePlace = dataStorePlace;
	}

	public String getNetDiskUrl() {
		return netDiskUrl;
	}

	public void setNetDiskUrl(String netDiskUrl) {
		this.netDiskUrl = netDiskUrl;
	}

	public String getNetDiskPassword() {
		return netDiskPassword;
	}

	public void setNetDiskPassword(String netDiskPassword) {
		this.netDiskPassword = netDiskPassword;
	}

	public EditDatasetDetail(String id, String datasetTypeId, String title, String subTitle, Long dataSize, String logo,
			String dataDesc, String dataTable, String fileCode, String fileName, String dataStorePlace,
			String netDiskUrl, String netDiskPassword) {
		super();
		this.id = id;
		this.datasetTypeId = datasetTypeId;
		this.title = title;
		this.subTitle = subTitle;
		this.dataSize = dataSize;
		this.logo = logo;
		this.dataDesc = dataDesc;
		this.dataTable = dataTable;
		this.fileCode = fileCode;
		this.fileName = fileName;
		this.dataStorePlace = dataStorePlace;
		this.netDiskUrl = netDiskUrl;
		this.netDiskPassword = netDiskPassword;
	}

}
