package com.macro.mall.params;

import java.util.List;

import com.macro.mall.entity.Permission;

public class RoleBackWithPermission {
	private String roleId;
	private String name;
	private List<Permission> permissions;

	public String getRoleId() {
		return roleId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public RoleBackWithPermission setRoleId(String roleId) {
		this.roleId = roleId;
		return this;
	}

	public List<Permission> getPermissions() {
		return permissions;
	}

	public RoleBackWithPermission setPermissions(List<Permission> permissions) {
		this.permissions = permissions;
		return this;
	}

	public RoleBackWithPermission() {
		super();
	}
	
	

}
