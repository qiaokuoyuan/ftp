package com.macro.mall.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
public class HumanRole extends BaseEntity {

	private String roleName;

	@ManyToMany(fetch = FetchType.LAZY, mappedBy = "humanRoles", cascade = CascadeType.PERSIST)
	@JsonIgnore
	private List<Human> humans;

	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JsonIgnore
	private List<Permission> permissions;

//	当前角色是否对游客有效
	@Column(columnDefinition = "bit default 0")
	private Boolean avaliableToTourist = false;

	public HumanRole() {
		// TODO Auto-generated constructor stub
	}

	public Boolean getAvaliableToTourist() {
		return avaliableToTourist;
	}

	public void setAvaliableToTourist(Boolean avaliableToTourist) {
		this.avaliableToTourist = avaliableToTourist;
	}

	public List<Human> getHumans() {
		return humans;
	}

	public void setHumans(List<Human> humans) {
		this.humans = humans;
	}

	public List<Permission> getPermissions() {
		return permissions;
	}

	public void setPermissions(List<Permission> permissions) {
		this.permissions = permissions;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	@Override
	public String toString() {
		return "HumanRole [roleName=" + roleName + ", humans=" + humans + "]";
	}

}
