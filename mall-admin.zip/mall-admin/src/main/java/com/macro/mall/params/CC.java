package com.macro.mall.params;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CC {

	public List<Object> datas;

	public CC() {
		this.datas = new ArrayList<>();
	}

	public CC(Object... objs) {
		datas = Arrays.asList(objs);
	}
}
