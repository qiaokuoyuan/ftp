package com.macro.mall.controller;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.Collect;
import com.macro.mall.entity.Human;
import com.macro.mall.jpa.CollectRepo;
import com.macro.mall.util.BeanTool;

@Controller
@RequestMapping("/collect")
public class CollectController {

	@Autowired
	public BeanTool beanTool;

	@Value("${token_name}")
	public String token_name;

	@Autowired
	private CollectRepo collectRepo;

	public CollectRepo getCollectRepo() {
		return collectRepo;
	}

	public void setCollectRepo(CollectRepo collectRepo) {
		this.collectRepo = collectRepo;
	}

	/**
	 * 添加收藏关系
	 * 
	 * @return
	 */
	@RequestMapping("/addCollect")
	@ResponseBody
	public Object addCollect(HttpServletRequest request, String targetId) {
		try {
//			获取当前用户
			Human human = beanTool.getHumanByHeader(request, token_name);
			if (human == null) {
				return new CommonResult().failed("您未登陆");
			} else {

//				检查是否已经收藏过
				if (collectRepo.isUserCollect(human.getId(), targetId)) {
					return new CommonResult().failed("您已经收藏过");
				} else {
					Collect c = new Collect();
					c.setId(UUID.randomUUID().toString());
					c.setTargetId(targetId);
					c.setUserid(human.getId());
					collectRepo.save(c);
					return new CommonResult().success(c.getId());
				}

			}
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 删除收藏关系
	 * 
	 * @return
	 */
	@RequestMapping("/delCollect")
	@ResponseBody
	public Object delCollect(String id) {
		try {
			collectRepo.delete(id);
			return new CommonResult().success("删除成功");
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

}
