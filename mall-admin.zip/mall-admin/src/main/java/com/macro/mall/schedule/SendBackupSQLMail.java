package com.macro.mall.schedule;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.macro.mall.util.BeanTool;

@Component
public class SendBackupSQLMail {

	@Autowired
	private BeanTool beanTool;
	
	
	
	@Value("$spring.datasource.username{}")
	String mysql_username;
	
	@Value("${spring.datasource.password}")
	String mysql_password;
	
	@Value("${backup.mysql.tempdir}")
	String backup_mysql_tempdir;
	
	
	
	public BeanTool getBeanTool() {
		return beanTool;
	}

	public void setBeanTool(BeanTool beanTool) {
		this.beanTool = beanTool;
	}
	
//	
//	@Scheduled(cron="*/5 * * * * ?")
//	public void backupMYSQL() {
//		System.err.println("触发器");
//		
//		String cmdString="mysqldump --all-databases -u root -p密码 >/home/ubuntu/data_backup/mysql$rq.sql ";
//
//		
//		
//	}
	
	
	public void senBackupSQLMail() {
		
	}
	
}
