package com.macro.mall.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.macro.mall.entity.About;

public interface AboutRepo extends JpaRepository<About, String>{
	
	List<About> findByIsActive(Boolean isActive);
	
	@Modifying
	@Transactional
	@Query(value="update About a set a.isActive = 1 where a.id=?1")
	
	Integer activeOne(String id);
	
	@Modifying
	@Transactional
	@Query(value= "update About a set a.isActive=0")
	Integer disactiveAll() ;
}
