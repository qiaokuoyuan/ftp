package com.macro.mall.util;

import com.fasterxml.jackson.annotation.ObjectIdGenerator.IdKey;
import com.fasterxml.jackson.annotation.ObjectIdResolver;

public class MyResolver implements ObjectIdResolver {

	@Override
	public void bindItem(IdKey id, Object pojo) {
		// TODO Auto-generated method stub
		Integer aInteger=1;

	}

	@Override
	public Object resolveId(IdKey id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ObjectIdResolver newForDeserialization(Object context) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean canUseFor(ObjectIdResolver resolverType) {
		// TODO Auto-generated method stub
		return false;
	}

}
