package com.macro.mall.jpa;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.macro.mall.entity.Comment;
import com.macro.mall.params.CommentListFront;

@Component
public interface CommentRepo extends JpaRepository<Comment, String> {

	List<Comment> findByTargetId(String targetId);

	@Query(value = "select c.*, u.icon from Comment as c left join ums_admin u on c.creator=u.uuid where c.target_Id=?1", nativeQuery = true)
	List<Object> _find_by_targetId_with_logo(String targetId);
	
	@Query(value="select " + 
			"	c.id,\r\n" + 
			"	c.content,\r\n" + 
			"	c.createTime \r\n" + 
			
			"from com.macro.mall.entity.Comment c" + 
			"	where c.targetId=?1\r\n" + 
			"\r\n" + 
			"")
	List<Object> getFrontCommentsByTargetId(String targetId);

}
