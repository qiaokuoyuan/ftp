package com.macro.mall.params;

import java.util.List;
import java.util.stream.Collectors;

import com.macro.mall.entity.Human;
import com.macro.mall.entity.HumanRole;

public class UserWithRoleName {
	private String id;
	private String username;
	private String nickname;
	private String email;
	private List<HumanRole> roles;

	
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<HumanRole> getRoles() {
		return roles;
	}

	public void setRoles(List<HumanRole> roles) {
		this.roles = roles;
	}

	public UserWithRoleName() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * 从human中初始化
	 * 
	 * @param h
	 * @return
	 */
	public static UserWithRoleName fromHuman(Human h) {
		UserWithRoleName newUser = new UserWithRoleName();
		newUser.setId(h.getId());
		newUser.setUsername(h.getUsername());
		newUser.setNickname(h.getNickname());
		newUser.setEmail(h.getEmail());
		newUser.setRoles(h.getHumanRoles().stream().map(e -> {
			e.setCreatorHuman(null);
			e.setHumans(null);
			e.setPermissions(null);
			return e;
		}).collect(Collectors.toList()));

		return newUser;
	}
}
