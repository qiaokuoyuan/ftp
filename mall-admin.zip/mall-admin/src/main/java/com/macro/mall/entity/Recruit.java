package com.macro.mall.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

@Entity
public class Recruit  extends BaseEntity{
	
//	招聘信息标题
	private String title;
	
//	招聘信息内容
	
	@Column(columnDefinition="TEXT")
	private String content;
	
//	工作地址
	private String location;
	
//	月薪区间
	private Integer salaryMonthMin;
	private Integer salaryMonthMax;
	
	
	private Date beginTime;
	
	private Date endTime;
	
	
	
public Date getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}


	//	招聘信息来源
	private String informationFrom;
	
//	是否已经失效
	private Boolean isDisabled;

//	失效原因
	private String disableReason;
	
	@OneToOne
	private Company company;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Integer getSalaryMonthMin() {
		return salaryMonthMin;
	}

	public void setSalaryMonthMin(Integer salaryMonthMin) {
		this.salaryMonthMin = salaryMonthMin;
	}

	public Integer getSalaryMonthMax() {
		return salaryMonthMax;
	}

	public void setSalaryMonthMax(Integer salaryMonthMax) {
		this.salaryMonthMax = salaryMonthMax;
	}



	public String getInformationFrom() {
		return informationFrom;
	}

	public void setInformationFrom(String informationFrom) {
		this.informationFrom = informationFrom;
	}

	public Boolean getIsDisabled() {
		return isDisabled;
	}

	public void setIsDisabled(Boolean isDisabled) {
		this.isDisabled = isDisabled;
	}

	public String getDisableReason() {
		return disableReason;
	}

	public void setDisableReason(String disableReason) {
		this.disableReason = disableReason;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}
	
	
	public Recruit() {
		// TODO Auto-generated constructor stub
	}
}
