package com.macro.mall.jpa;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.macro.mall.entity.BlogType;

@Component
public interface BlogTypeRepo extends JpaRepository<BlogType, String> {

	List<BlogType> findByTitle(String title);

	@Modifying
	@Transactional
	@Query(value = "UPDATE blog_type SET logo=?3,title=?2 WHERE ID=?1", nativeQuery = true)
	void updateTitleAndLogo(String id, String title, String logo);
}
