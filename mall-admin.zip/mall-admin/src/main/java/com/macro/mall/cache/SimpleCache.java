package com.macro.mall.cache;

import java.util.HashMap;
import java.util.Map;

public  class SimpleCache {
	public static Map<String, Object> cacheMap=new HashMap<>();
}
