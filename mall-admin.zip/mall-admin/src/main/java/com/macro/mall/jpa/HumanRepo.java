package com.macro.mall.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.macro.mall.entity.Human;
import com.macro.mall.params.HumanInfoFront;
import com.macro.mall.params.HumanPermissionString;

public interface HumanRepo extends JpaRepository<Human, String> {

	List<Human> findByUsername(String username);

//	获取当前用户可以访问的前端接口和后端接口集合
	@Query(value = "select new com.macro.mall.params.HumanPermissionString(p.frontUrls,p.backUrls) from Human h right join h.humanRoles r left join r.permissions p  where r.avaliableToTourist=1 or h.id=?")
	public List<HumanPermissionString> getHumanPermissionString(String userid);
	
//	获取当前用户前端显示信息和可以访问的前端接口和后端接口集合
	@Query(value = "select \r\n" + 
			"	new com.macro.mall.params.HumanInfoFront(\r\n" + 
			"	h.id,\r\n" + 
			"	h.username,\r\n" + 
			"	h.nickname,\r\n" + 
			"	h.logo,\r\n" + 
			"	(\r\n" + 
			"		select p.frontUrls from Human h2 right join h2.humanRoles r left join r.permissions p  where r.avaliableToTourist=1 or h2.id=?1\r\n" + 
			"	),\r\n" + 
			"	(\r\n" + 
			"		select p.backUrls from Human h3 right join h3.humanRoles r left join r.permissions p  where r.avaliableToTourist=1 or h3.id=?1\r\n" + 
			"	)\r\n" + 
			"	) \r\n" + 
			"	from Human h  where h.id=?1")
	public HumanInfoFront getHumanInfoFront(String userid);
}
