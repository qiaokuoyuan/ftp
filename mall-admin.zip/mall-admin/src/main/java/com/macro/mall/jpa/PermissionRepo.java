package com.macro.mall.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.macro.mall.entity.Human;
import com.macro.mall.entity.HumanRole;
import com.macro.mall.entity.Permission;

public interface PermissionRepo extends JpaRepository<Permission, String> {
	List<Permission> findByBackUrlsLike(String like);

	@Query(nativeQuery = true, value = "SELECT GROUP_CONCAT(p.back_urls) FROM human h 	LEFT JOIN human_human_roles hhr ON		h.id=hhr.humans_id"
			+ "	LEFT JOIN human_role hr ON		hhr.human_roles_id=hr.id	LEFT JOIN human_role_permissions hrp ON		hr.id=hrp.human_roles_id"
			+ "	LEFT JOIN permission p ON	p.id=hrp.permissions_id	WHERE h.id=?" + "	GROUP BY h.id")
	String getBackUrlsOfHuman(String humanId);
}
