package com.macro.mall.enu;

public enum TimesCount {
	DOWNLOAD,ASDASD
}
