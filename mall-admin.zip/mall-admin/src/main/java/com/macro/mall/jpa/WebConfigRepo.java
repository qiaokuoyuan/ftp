package com.macro.mall.jpa;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.macro.mall.entity.WebConfig;

public interface WebConfigRepo extends JpaRepository<WebConfig, String> {
	
	@Transactional
	@Modifying
	@Query(value = "UPDATE Web_Config SET tourist_Front_Permission =?", nativeQuery = true)
	void updateTouristFront(String permission);
	
	@Transactional
	@Modifying
	@Query(value = "UPDATE Web_Config SET tourist_Back_Permission =?", nativeQuery = true)
	void updateTouristBack(String permission);
}
