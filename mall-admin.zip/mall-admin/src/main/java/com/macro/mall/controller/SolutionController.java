package com.macro.mall.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.Solution;
import com.macro.mall.jpa.SolutionRepo;

@RequestMapping("/solution")
@Controller
public class SolutionController extends BaseController<Solution> {

	@Autowired
	private SolutionRepo solutionRepo;

	@Autowired
	public void setRepo() {
		this.setRepo(this.solutionRepo);
	}

	public SolutionRepo getSolutionRepo() {
		return solutionRepo;
	}

	public void setSolutionRepo(SolutionRepo solutionRepo) {
		this.solutionRepo = solutionRepo;
	}

	@RequestMapping("/getSolutionListItem")
	@ResponseBody
	public Object getSolutionListItem(@RequestParam(defaultValue = "1") Integer pageIndex,
			@RequestParam(defaultValue = "10") Integer pageSize) {

		try {
			pageIndex--;
			PageRequest pageRequest = new PageRequest(pageIndex, pageSize);

			return new CommonResult().success(solutionRepo.getSolutionListItem(pageRequest));
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}

	}
}
