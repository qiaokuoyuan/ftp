package com.macro.mall.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.macro.mall.entity.Competition;

public interface CompetitionRepo extends JpaRepository<Competition, String> {

}
