package com.macro.mall.controller;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.macro.mall.dto.CommonResult;
import com.macro.mall.entity.BlogType;
import com.macro.mall.jpa.BlogTypeRepo;
import com.macro.mall.util.BeanTool;

@RequestMapping("/blogType")
@Controller
@Component
public class BlogTypeController {

	@Autowired
	private BlogTypeRepo blogTypeRepo;

	@Autowired
	private BeanTool beanTool;

	

	@Value(value = "${token_name}")
	public String headerName;

	public BeanTool getBeanTool() {
		return beanTool;
	}

	public void setBeanTool(BeanTool beanTool) {
		this.beanTool = beanTool;
	}



	public BlogTypeRepo getBlogTypeRepo() {
		return blogTypeRepo;
	}

	public void setBlogTypeRepo(BlogTypeRepo blogTypeRepo) {
		this.blogTypeRepo = blogTypeRepo;
	}

	/**
	 * 获取所有 blog 类型
	 * 
	 * @return
	 */
	@RequestMapping("/getBlogTypes")
	@ResponseBody
	public Object getBlogTypes(@RequestParam(defaultValue = "1") Integer pageIndex,
			@RequestParam(defaultValue = "10") Integer pageSize) {
		try {
			--pageIndex;

			return new CommonResult().success(blogTypeRepo.findAll(new PageRequest(pageIndex, pageSize)));
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 添加blog类型
	 * 
	 * @return
	 */
	@RequestMapping("/addBlogType")
	@ResponseBody
	public Object addBlogType(HttpServletRequest request ,String title, String logo) {
		try {
			BlogType blogType = new BlogType();
			blogType.setCreator(beanTool.getHumanByHeader(request, headerName).getId());
			blogType.setId(UUID.randomUUID().toString());
			blogType.setTitle(title);
			blogType.setLogo(logo);
			blogTypeRepo.save(blogType);
			return new CommonResult().success(blogType.getId());
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	/**
	 * 删除blog类型
	 * 
	 * @return
	 */
	@RequestMapping("/delBlogType")
	@ResponseBody
	public Object delBlogType(String id) {
		try {
			blogTypeRepo.delete(id);
			return new CommonResult().success("删除成功");
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

	@RequestMapping("/updateBlogType")
	@ResponseBody
	public Object updateBlogType(BlogType blogType) {
		try {
			blogTypeRepo.updateTitleAndLogo(blogType.getId(), blogType.getTitle(), blogType.getLogo());
			return new CommonResult().success("编辑成功");
		} catch (Exception e) {
			return new CommonResult().failed(e.getMessage());
		}
	}

}
