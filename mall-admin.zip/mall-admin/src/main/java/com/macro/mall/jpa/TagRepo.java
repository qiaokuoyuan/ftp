package com.macro.mall.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.macro.mall.entity.Tag;

public interface TagRepo extends JpaRepository<Tag	,String>{

}
