package com.macro.mall.entity;

import java.util.Arrays;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
public class Human extends BaseEntity {

//	
//	public static String DEFAULT_FRONT_URLString="/blog/getBlogs,/simpleLogin";
//	public static String DEFAULT_BACK_URLString="/blog/getBlogs,/simpleLogin/login,/simpleLogin/md5,/dataset/getDatasets,/blog/getBlogs,/solution/getSolutions";
	private String username="";
	private String nickname="";
	private String logo="";

	private String passwordMD5="";
	private String raw_password="";
	private String email="";

	private Boolean isSuperman = false;

//	当前用户创建了哪些用户

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "creatorHuman", cascade = CascadeType.REMOVE)
	@JsonIgnore
	private List<Human> humanCreated;

	@ManyToMany(fetch = FetchType.EAGER)
	@JsonIgnore
	private List<HumanRole> humanRoles;

	public Boolean getIsSuperman() {
		return isSuperman;
	}

	public void setIsSuperman(Boolean isSuperman) {
		this.isSuperman = isSuperman;
	}

	public List<Human> getHumanCreated() {
		return humanCreated;
	}

	public void setHumanCreated(List<Human> humanCreated) {
		this.humanCreated = humanCreated;
	}

	public List<HumanRole> getHumanRoles() {
		return humanRoles;
	}

	public void setHumanRoles(List<HumanRole> humanRoles) {
		this.humanRoles = humanRoles;
	}

	public Human() {
		super();
	}

	public String getUsername() {
		return username;
	}

	public Human setUsername(String username) {
		this.username = username;
		return this;
	}

	public String getNickname() {
		return nickname;
	}

	public Human setNickname(String nickname) {
		this.nickname = nickname;
		return this;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	@JsonIgnore
	public String getPasswordMD5() {
		return passwordMD5;
	}

	@JsonProperty
	public void setPasswordMD5(String passwordMD5) {
		this.passwordMD5 = passwordMD5;
	}

	@JsonIgnore
	public String getRaw_password() {
		return raw_password;
	}

	@JsonProperty
	public void setRaw_password(String raw_password) {
		this.raw_password = raw_password;
	}

	public String getEmail() {
		return email;
	}

	public Human setEmail(String email) {
		this.email = email;
		return this;
	}



	@Override
	public String toString() {
		return "Human [username=" + username + ", nickname=" + nickname + ", logo=" + logo + ", passwordMD5="
				+ passwordMD5 + ", raw_password=" + raw_password + ", email=" + email + "]";
	}
	
	

}
