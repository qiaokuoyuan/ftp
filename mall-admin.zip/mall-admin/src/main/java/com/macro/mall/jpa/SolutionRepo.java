package com.macro.mall.jpa;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.macro.mall.entity.Solution;
import com.macro.mall.params.SolutionListItem;

public interface SolutionRepo extends JpaRepository<Solution,String> {
 
	@Query(value="select\r\n" + 
			"	new com.macro.mall.params.SolutionListItem(\r\n" + 
			"	s.creatorHuman.logo,\r\n" + 
			"	s.creatorHuman.id,\r\n" + 
			"	s.creatorHuman.nickname,\r\n" + 
			"	s.logo,\r\n" + 
			"	c.title,\r\n" + 
			"	s.solutionTitle,\r\n" + 
			"	s.solutionRank,\r\n" + 
			"	s.solutionTop\r\n" + 
			"	)\r\n" + 
			"	\r\n" + 
			"	from \r\n" + 
			"		com.macro.mall.entity.Solution s ,\r\n" + 
			"		com.macro.mall.entity.Competition c\r\n" + 
			"	where \r\n" + 
			"		s.competitionId=c.id", countQuery="select count(1) from com.macro.mall.entity.Solution")
	public Page<SolutionListItem> getSolutionListItem(Pageable page);

}
