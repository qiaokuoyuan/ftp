package com.macro.mall.entity;

public class HasCreator {

	private String creator;

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public HasCreator() {
		super();
		// TODO Auto-generated constructor stub
	}

}
