package com.macro.mall.jpa;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.macro.mall.entity.UserCollect;

public interface UserCollectRepo extends JpaRepository<UserCollect, String> {
	
	/**
	 * 获取一个用户对某一种收藏类型的收藏个数
	 * @param userId
	 * @param collectType
	 * @return
	 */
	@Query("select count(1) from UserCollect where userId=userId and collectType=collectType")
	Integer userCollectCount(@Param("userId") String userId, @Param("collectType") String collectType);
	
	/**
	 * 获取一个用户对某所有类型收藏类型的收藏个数
	 * @param userId
	 * @return
	 */
	@Query("select collectType, count(1) as c from UserCollect where userId=userId group by collectType")
	Integer userAllCollectCount(@Param("userId") String userId);
	
	
}
