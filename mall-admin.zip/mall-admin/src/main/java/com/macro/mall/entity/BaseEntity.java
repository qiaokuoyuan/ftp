package com.macro.mall.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;

import com.fasterxml.jackson.annotation.JsonIgnore;

@MappedSuperclass
public class BaseEntity {
	@Id
	private String id;

	@ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.DETACH)
	@JsonIgnore
	private Human creatorHuman;

	private Date createTime;
	
	private String additionalDescribe;

	public String getAdditionalDescribe() {
		return additionalDescribe;
	}

	public void setAdditionalDescribe(String additionalDescribe) {
		this.additionalDescribe = additionalDescribe;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Human getCreatorHuman() {
		return creatorHuman;
	}

	public void setCreatorHuman(Human creatorHuman) {
		this.creatorHuman = creatorHuman;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

}
