package com.macro.mall.jpa;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.macro.mall.entity.Dataset;
import com.macro.mall.params.CC;
import com.macro.mall.params.DatasetDetailFront;
import com.macro.mall.params.DatasetListFront;
import com.macro.mall.params.EditDatasetDetail;

public interface DatasetRepo extends JpaRepository<Dataset, String> {

	@Transactional
	@Modifying
	@Query("update Dataset set paperDesc = ?2 where id=?1")
	void upadtePaperDesc(String id, String paperDesc);

	@Query(value = "select new com.macro.mall.params.DatasetDetailFront(\r\n" + "	d.id,\r\n" + "	d.title,\r\n"
			+ "	(select avg(r.rateScore) from com.macro.mall.entity.Rate r where r.targetId=:did),\r\n"
			+ "	(select count(1) from com.macro.mall.entity.Collect c where c.targetId=:did and c.userid=:uid),\r\n"
			+ "	(select count(1) from com.macro.mall.entity.Collect c where c.targetId=:did),\r\n"
			+ "	(select count(1) from com.macro.mall.entity.DownloadRecord dr where dr.targetId=:did),\r\n"
			+ "	d.dataSize,\r\n" + "	d.dataDesc,\r\n" + "	d.dataTable\r\n, d.logo,d.paperText" + "	)\r\n"
			+ "	\r\n" + " from com.macro.mall.entity.Dataset d\r\n" + "\r\n" + " where d.id=:did")
	DatasetDetailFront detail(@Param(value = "did") String datasetId, @Param(value = "uid") String userid);

//	根据关键词和类型id搜索
	@Query(value = "select new com.macro.mall.params.DatasetListFront(	\r\n" + 
			"	d.id,\r\n" + 
			"	d.title,\r\n" + 
			"	d.logo,\r\n" + 
			"	d.dataSize,\r\n" + 
			"	d.creatorHuman.nickname,\r\n" + 
			"	d.creatorHuman.logo,"
			+ "d.	creatorHuman.id	\r\n" + 
			")\r\n" + 
			"\r\n" + 
			"\r\n" + 
			" from  com.macro.mall.entity.Dataset d where d.datasetTypeId like  %?2  and d.title like %?1", countQuery = "select count(1) from  com.macro.mall.entity.Dataset d where d.datasetTypeId like %?2 and d.title like %?1")
	Page<DatasetListFront> search(String keyword, String datasetTypeId,  Pageable pageable);
	


}
