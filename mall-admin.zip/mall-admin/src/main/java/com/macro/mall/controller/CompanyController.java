package com.macro.mall.controller;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.macro.mall.entity.Company;
import com.macro.mall.entity.Recruit;
import com.macro.mall.jpa.CompanyRepo;
import com.macro.mall.jpa.RecruitRepo;

/**
 * 招聘信息控制器
 * 
 * @author Armageddon
 *
 */
@RequestMapping("/company")
@Controller
public class CompanyController extends BaseController<Company> {
	
	@Autowired
	private CompanyRepo companyRepo;


	
	public CompanyRepo getCompanyRepo() {
		return companyRepo;
	}



	public void setCompanyRepo(CompanyRepo companyRepo) {
		this.companyRepo = companyRepo;
	}



	@Autowired
	public void setRepo() {
		this.setRepo(this.companyRepo);
	}

}
