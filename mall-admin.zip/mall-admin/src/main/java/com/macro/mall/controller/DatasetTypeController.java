package com.macro.mall.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.macro.mall.entity.DatasetType;
import com.macro.mall.jpa.DatasetTypeRepo;

@RequestMapping("/datasetType")
@Controller
public class DatasetTypeController extends BaseController<DatasetType> {

	@Autowired
	private DatasetTypeRepo datasetTypeRepo;

	@Autowired
	public void setRepo() {
		setRepo(datasetTypeRepo);
	}

	public DatasetTypeRepo getDatasetTypeRepo() {
		return datasetTypeRepo;
	}

	public void setDatasetTypeRepo(DatasetTypeRepo datasetTypeRepo) {
		this.datasetTypeRepo = datasetTypeRepo;
	}

}
